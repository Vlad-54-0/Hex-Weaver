import type { ScoreEntry } from "../game/scores";
import { iconURL } from "../game/icons";
import { KIND_COLOR, KIND_LABEL, SPELLS } from "../game/spells";

export function SpellIcon({ id, size = 40 }: { id: string; size?: number }) {
  return <img src={iconURL(id)} width={size} height={size} alt={SPELLS[id]?.name} className="pix block" draggable={false} style={{ width: size, height: size }} />;
}

export function ScoreTable({ scores, highlight = -1, compact = false }: { scores: ScoreEntry[]; highlight?: number; compact?: boolean }) {
  const rows = compact ? scores.slice(0, 5) : scores;
  return (
    <div className="font-vt text-[20px] leading-6 w-full">
      <div className="flex text-[#8a7fb0] border-b-2 border-[#3a2d70] pb-1 mb-1 text-[17px]">
        <span className="w-9">#</span>
        <span className="flex-1">NAME</span>
        <span className="w-24 text-right">SCORE</span>
        <span className="w-14 text-right">WAVE</span>
      </div>
      {rows.length === 0 && <div className="text-[#6c6290] py-2 text-center">No legends yet. Be the first.</div>}
      {rows.map((s, i) => (
        <div key={s.date + "-" + i} className={"flex px-1 " + (i === highlight ? "bg-[#ffd166] text-[#2a1700] blink" : i === 0 ? "text-[#ffd166]" : i < 3 ? "text-[#e8e0ff]" : "text-[#a79fd0]")}>
          <span className="w-9">{i + 1}.</span>
          <span className="flex-1 truncate">{s.name}</span>
          <span className="w-24 text-right">{s.score.toLocaleString()}</span>
          <span className="w-14 text-right">{s.wave}</span>
        </div>
      ))}
    </div>
  );
}

export function KindTag({ kind }: { kind: keyof typeof KIND_LABEL }) {
  return (
    <span className="font-pixel text-[8px] px-1.5 py-1 text-[#120d22]" style={{ background: KIND_COLOR[kind] }}>
      {KIND_LABEL[kind]}
    </span>
  );
}
