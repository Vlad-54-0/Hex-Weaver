import { useEffect, useMemo, useState } from "react";
import type { AltarData } from "../game/engine";
import { sfx } from "../game/audio";
import { describeWand, KIND_COLOR, SPELLS } from "../game/spells";
import { KindTag, SpellIcon } from "./parts";

type Held = { src: "offer" | "slot"; idx: number } | null;

export function Altar({ data, onDone }: { data: AltarData; onDone: (wand: (string | null)[]) => void }) {
  const [wand, setWand] = useState<(string | null)[]>(data.wand);
  const [taken, setTaken] = useState<number>(-1);
  const [held, setHeld] = useState<Held>(null);
  const [inspect, setInspect] = useState<string | null>(null);
  const [lastPlaced, setLastPlaced] = useState<number>(-1);

  const info = useMemo(() => describeWand(wand), [wand]);
  const heldId = held ? (held.src === "offer" ? data.offers[held.idx] : wand[held.idx]) : null;
  const shown = inspect || heldId;

  const pickOffer = (i: number) => {
    if (taken >= 0) return;
    sfx.ui();
    if (held?.src === "offer" && held.idx === i) setHeld(null);
    else setHeld({ src: "offer", idx: i });
    setInspect(data.offers[i]);
  };

  const clickSlot = (i: number) => {
    if (held?.src === "offer") {
      const id = data.offers[held.idx];
      setWand((w) => {
        const n = [...w];
        n[i] = id;
        return n;
      });
      setTaken(held.idx);
      setHeld(null);
      setLastPlaced(i);
      sfx.place();
      return;
    }
    if (held?.src === "slot") {
      if (held.idx !== i) {
        setWand((w) => {
          const n = [...w];
          [n[held.idx], n[i]] = [n[i], n[held.idx]];
          return n;
        });
        sfx.place();
      }
      setHeld(null);
      return;
    }
    if (wand[i]) {
      sfx.ui();
      setHeld({ src: "slot", idx: i });
      setInspect(wand[i]);
    }
  };

  const discard = () => {
    if (held?.src !== "slot") return;
    const i = held.idx;
    setWand((w) => {
      const n = [...w];
      n[i] = null;
      return n;
    });
    setHeld(null);
    sfx.ui();
  };

  // keyboard shortcuts: 1-3 select offers, Enter/Space start
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Digit1" || e.code === "Digit2" || e.code === "Digit3") {
        pickOffer(Number(e.code.slice(5)) - 1);
      } else if (e.code === "Enter") {
        e.preventDefault();
        onDone(wand);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const spellDef = shown ? SPELLS[shown] : null;
  const hungry = info.cycleTime > 0 && info.totalMana / info.cycleTime > 54 * 1.1;

  return (
    <div className="absolute inset-0 z-20 overflow-y-auto scroll-thin bg-[#05030c]/80 backdrop-blur-[2px] flex">
      <div className="panel pop-in m-auto w-full max-w-3xl p-4 sm:p-6 my-3 sm:my-6 mx-2 sm:mx-auto">
        <div className="text-center mb-4">
          <div className="font-pixel text-[#7dff9a] text-[13px] sm:text-[16px] tracking-wide">WAVE {data.wave} CLEARED</div>
          <div className="font-vt text-[20px] text-[#a79fd0] mt-2">
            Spell Altar · healed <span className="text-[#7dff9a]">+{data.healed} HP</span> · mana restored
            {data.newSlot && <span className="text-[#ffd166] blink"> · NEW WAND SLOT!</span>}
          </div>
        </div>

        <div className="font-pixel text-[9px] text-[#ffd166] mb-2">1 · CLAIM A SPELL <span className="text-[#6c6290]">(keys 1-3)</span></div>
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-5">
          {data.offers.map((id, i) => {
            const s = SPELLS[id];
            const sel = held?.src === "offer" && held.idx === i;
            return (
              <button
                key={i}
                disabled={taken >= 0 && taken !== i}
                onClick={() => pickOffer(i)}
                className={"card p-2 sm:p-3 flex flex-col items-center gap-1.5 text-center " + (sel ? "sel" : "")}
                style={{ ["--c" as string]: KIND_COLOR[s.kind] }}
              >
                <div className="float" style={{ animationDelay: i * 0.3 + "s" }}>
                  <SpellIcon id={id} size={52} />
                </div>
                <div className="font-pixel text-[8px] sm:text-[9px] leading-3 text-white min-h-6 flex items-center">{s.name}</div>
                <KindTag kind={s.kind} />
                <div className="font-vt text-[17px] leading-4 text-[#b9b0dc] hidden sm:block min-h-12">{s.desc}</div>
                <div className="font-vt text-[16px] text-[#4aa8ff]">mana {s.mana}</div>
                {taken === i && <div className="font-pixel text-[8px] text-[#7dff9a]">CLAIMED</div>}
              </button>
            );
          })}
        </div>

        <div className="font-pixel text-[9px] text-[#ffd166] mb-2 flex items-center justify-between gap-2 flex-wrap">
          <span>2 · ARRANGE YOUR WAND</span>
          <span className="font-vt text-[17px] text-[#8a7fb0] normal-case">
            {held?.src === "offer" ? "Tap a slot to place it (replaces what's there)" : held?.src === "slot" ? "Tap another slot to swap" : "Spells fire left → right. Order matters!"}
          </span>
        </div>
        <div className="flex flex-wrap gap-2 mb-3 justify-center sm:justify-start">
          {wand.map((id, i) => {
            const s = id ? SPELLS[id] : null;
            const sel = held?.src === "slot" && held.idx === i;
            return (
              <div key={i} className="flex flex-col items-center gap-1">
                <button
                  className={"slot " + (s ? "" : "empty ") + (sel ? "sel " : "") + (held?.src === "offer" ? "target" : "")}
                  style={{ ["--c" as string]: s ? KIND_COLOR[s.kind] : undefined }}
                  onClick={() => clickSlot(i)}
                  onMouseEnter={() => setInspect(id)}
                  onMouseLeave={() => setInspect(null)}
                >
                  {id && (
                    <div className={"absolute inset-0 flex items-center justify-center " + (lastPlaced === i ? "pop-in" : "")}>
                      <SpellIcon id={id} size={38} />
                    </div>
                  )}
                </button>
                <span className="font-pixel text-[7px] text-[#6c6290]">{i + 1}</span>
              </div>
            );
          })}
        </div>

        <div className="min-h-[62px] bg-[#0a0616] border-2 border-[#2c2258] p-2 mb-3 flex items-center gap-3">
          {spellDef ? (
            <>
              <SpellIcon id={spellDef.id} size={40} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-pixel text-[9px] text-white">{spellDef.name}</span>
                  <KindTag kind={spellDef.kind} />
                  <span className="font-vt text-[16px] text-[#4aa8ff]">mana {spellDef.mana}</span>
                </div>
                <div className="font-vt text-[18px] leading-5 text-[#b9b0dc]">{spellDef.desc}</div>
              </div>
              {held?.src === "slot" && (
                <button className="btn btn-ghost !text-[9px] !px-3 !py-2" onClick={discard}>
                  DISCARD
                </button>
              )}
            </>
          ) : (
            <div className="font-vt text-[18px] text-[#6c6290]">
              Tip: Modifiers & Multicast affect the spells <em>after</em> them. Trigger casts the spell 2 slots later when the first one hits.
            </div>
          )}
        </div>

        <div className="bg-[#0a0616] border-2 border-[#2c2258] p-2 mb-4 font-vt text-[18px] leading-5">
          <div className="font-pixel text-[8px] text-[#8a7fb0] mb-1.5">CAST PREVIEW</div>
          {info.casts.length === 0 && <div className="text-[#6c6290]">Your wand is empty!</div>}
          {info.casts.map((c, i) => (
            <div key={i} className="flex gap-2">
              <span className="text-[#6c6290] w-6 shrink-0">#{i + 1}</span>
              <span className="flex-1 text-[#e8e0ff]">{c.labels.length ? c.labels.join("  +  ") : <span className="text-[#6c6290]">(nothing)</span>}</span>
              <span className="text-[#4aa8ff] shrink-0">{c.mana}m</span>
            </div>
          ))}
          {info.casts.length > 0 && (
            <div className="mt-1.5 pt-1.5 border-t border-[#2c2258] text-[#a79fd0]">
              Full cycle {info.cycleTime.toFixed(2)}s · {info.totalMana} mana
              {hungry && <span className="text-[#ff9a4d]"> · ⚠ mana-hungry, you'll stall</span>}
            </div>
          )}
        </div>

        <div className="flex justify-center">
          <button className="btn btn-go" onClick={() => onDone(wand)}>
            START WAVE {data.wave + 1} ▶
          </button>
        </div>
        <div className="text-center font-vt text-[16px] text-[#6c6290] mt-2">press ENTER</div>
      </div>
    </div>
  );
}
