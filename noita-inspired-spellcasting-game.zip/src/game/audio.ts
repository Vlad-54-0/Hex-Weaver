// Tiny WebAudio synth – no assets required.

type Wave = OscillatorType;

class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private last: Record<string, number> = {};
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem("hexweaver:muted") === "1";
    } catch {
      /* ignore */
    }
  }

  unlock() {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.32;
        const comp = this.ctx.createDynamicsCompressor();
        this.master.connect(comp);
        comp.connect(this.ctx.destination);
        const len = this.ctx.sampleRate * 1;
        this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      } catch {
        this.ctx = null;
      }
    }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem("hexweaver:muted", m ? "1" : "0");
    } catch {
      /* ignore */
    }
    if (this.master) this.master.gain.value = m ? 0 : 0.32;
  }

  private gate(name: string, ms: number) {
    const now = performance.now();
    if (now - (this.last[name] || 0) < ms) return false;
    this.last[name] = now;
    return true;
  }

  private tone(freq: number, dur: number, type: Wave, vol: number, slideTo = 0, delay = 0) {
    const c = this.ctx;
    if (!c || !this.master || this.muted) return;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, freq: number, slideTo = 0, delay = 0) {
    const c = this.ctx;
    if (!c || !this.master || !this.noiseBuf || this.muted) return;
    const t = c.currentTime + delay;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(freq, t);
    if (slideTo) f.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(this.master);
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }

  cast(kind: string) {
    if (!this.gate("cast" + kind, 45)) return;
    const r = 1 + (Math.random() - 0.5) * 0.12;
    switch (kind) {
      case "fire":
        this.noise(0.25, 0.35, 1800, 300);
        this.tone(180 * r, 0.22, "sawtooth", 0.12, 90);
        break;
      case "frost":
        this.tone(1300 * r, 0.12, "triangle", 0.12, 1800);
        this.tone(1950 * r, 0.1, "sine", 0.06, 2600);
        break;
      case "zap":
        this.tone(900 * r, 0.12, "sawtooth", 0.12, 140);
        this.noise(0.1, 0.2, 5000, 800);
        break;
      case "bomb":
        this.tone(160 * r, 0.18, "square", 0.12, 70);
        break;
      case "hole":
        this.tone(90, 0.5, "sine", 0.3, 40);
        this.tone(220, 0.4, "triangle", 0.08, 60);
        break;
      case "bounce":
        this.tone(520 * r, 0.12, "square", 0.08, 760);
        break;
      default:
        this.tone(720 * r, 0.09, "square", 0.08, 320);
    }
  }

  hit() {
    if (!this.gate("hit", 35)) return;
    this.noise(0.06, 0.22, 3000, 600);
    this.tone(260 + Math.random() * 60, 0.06, "square", 0.07, 120);
  }

  kill(combo: number) {
    if (!this.gate("kill", 25)) return;
    const base = 330 * Math.pow(1.0595, Math.min(combo, 24));
    this.tone(base, 0.12, "triangle", 0.18, base * 1.5);
    this.noise(0.14, 0.22, 2500, 400);
  }

  boom(size: number) {
    if (!this.gate("boom", 40)) return;
    this.noise(0.25 + size * 0.5, 0.5 + size * 0.3, 1400 + size * 800, 60);
    this.tone(110 - size * 40, 0.3 + size * 0.3, "sine", 0.4, 30);
  }

  react() {
    if (!this.gate("react", 80)) return;
    [660, 880, 1320].forEach((f, i) => this.tone(f, 0.18, "triangle", 0.14, f * 1.02, i * 0.05));
  }

  freeze() {
    if (!this.gate("freeze", 60)) return;
    this.tone(2000, 0.2, "sine", 0.1, 3200);
    this.tone(2600, 0.15, "triangle", 0.06, 1800, 0.03);
  }

  shatter() {
    this.noise(0.18, 0.4, 7000, 1500);
    this.tone(1800, 0.14, "square", 0.08, 600);
  }

  hurt() {
    this.noise(0.3, 0.5, 900, 120);
    this.tone(150, 0.3, "sawtooth", 0.25, 50);
  }

  dash() {
    this.noise(0.18, 0.3, 4000, 600);
  }

  pickup() {
    this.tone(660, 0.08, "triangle", 0.14);
    this.tone(990, 0.12, "triangle", 0.14, 0, 0.06);
  }

  wave() {
    [392, 523, 659, 784].forEach((f, i) => this.tone(f, 0.25, "triangle", 0.16, 0, i * 0.08));
  }

  start() {
    [196, 294, 392, 587].forEach((f, i) => this.tone(f, 0.3, "square", 0.08, 0, i * 0.07));
  }

  ui() {
    if (!this.gate("ui", 30)) return;
    this.tone(520, 0.06, "square", 0.07, 780);
  }

  place() {
    this.tone(440, 0.09, "triangle", 0.15, 880);
    this.tone(880, 0.12, "sine", 0.1, 1320, 0.05);
  }

  empty() {
    if (!this.gate("empty", 220)) return;
    this.tone(120, 0.1, "square", 0.08, 90);
  }

  over() {
    [392, 330, 262, 196].forEach((f, i) => this.tone(f, 0.45, "sawtooth", 0.14, f * 0.9, i * 0.17));
  }

  spawn() {
    if (!this.gate("spawn", 90)) return;
    this.tone(200, 0.15, "sine", 0.05, 400);
  }
}

export const sfx = new Sfx();
