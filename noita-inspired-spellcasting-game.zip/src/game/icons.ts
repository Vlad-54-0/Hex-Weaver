// Procedural spell icons (32x32), cached as canvases + data URLs.

const cache: Record<string, HTMLCanvasElement> = {};
const urlCache: Record<string, string> = {};

type C = CanvasRenderingContext2D;

function glow(c: C, x: number, y: number, r: number, color: string) {
  const g = c.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  c.fillStyle = g;
  c.fillRect(x - r, y - r, r * 2, r * 2);
}

function dot(c: C, x: number, y: number, r: number, color: string) {
  c.fillStyle = color;
  c.beginPath();
  c.arc(x, y, r, 0, Math.PI * 2);
  c.fill();
}

function poly(c: C, pts: number[], color: string) {
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]);
  c.closePath();
  c.fill();
}

const drawers: Record<string, (c: C) => void> = {
  spark: (c) => {
    glow(c, 16, 16, 15, "rgba(100,255,255,.6)");
    c.strokeStyle = "#aff";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(16, 3); c.lineTo(16, 29); c.moveTo(3, 16); c.lineTo(29, 16);
    c.moveTo(7, 7); c.lineTo(25, 25); c.moveTo(25, 7); c.lineTo(7, 25);
    c.stroke();
    dot(c, 16, 16, 5, "#fff");
  },
  fireball: (c) => {
    glow(c, 16, 17, 15, "rgba(255,140,40,.6)");
    poly(c, [16, 2, 24, 14, 26, 22, 20, 29, 12, 29, 6, 22, 8, 14, 12, 16], "#ff6a1a");
    poly(c, [16, 10, 21, 18, 21, 24, 16, 28, 11, 24, 11, 18], "#ffb347");
    poly(c, [16, 17, 18, 22, 16, 26, 14, 22], "#fff3b0");
  },
  frost: (c) => {
    glow(c, 16, 16, 15, "rgba(120,200,255,.5)");
    poly(c, [16, 2, 23, 16, 16, 30, 9, 16], "#7cc8ff");
    poly(c, [16, 2, 23, 16, 16, 16], "#d8f3ff");
    poly(c, [16, 16, 23, 16, 16, 30], "#4a9be0");
  },
  lightning: (c) => {
    glow(c, 16, 16, 15, "rgba(255,240,80,.5)");
    poly(c, [19, 2, 8, 18, 15, 18, 12, 30, 25, 12, 17, 12, 22, 2], "#ffee55");
    poly(c, [18, 6, 12, 17, 18, 17, 16, 24, 21, 14, 15, 14], "#fff9c4");
  },
  bounce: (c) => {
    glow(c, 22, 22, 10, "rgba(255,100,200,.5)");
    c.strokeStyle = "#ff8fd8";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(4, 6); c.lineTo(14, 26); c.lineTo(24, 8); c.lineTo(28, 14);
    c.stroke();
    dot(c, 26, 12, 4.5, "#ff66cc");
    dot(c, 25, 11, 1.8, "#fff");
  },
  bomb: (c) => {
    dot(c, 15, 19, 10, "#3a3f55");
    dot(c, 12, 16, 3, "#6b7391");
    c.strokeStyle = "#caa46a";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(20, 11); c.quadraticCurveTo(24, 6, 27, 6);
    c.stroke();
    glow(c, 27, 6, 6, "rgba(255,200,80,.9)");
    dot(c, 27, 6, 2, "#fff");
  },
  blackhole: (c) => {
    glow(c, 16, 16, 16, "rgba(170,100,255,.7)");
    c.strokeStyle = "#c9a0ff";
    c.lineWidth = 2;
    c.beginPath(); c.arc(16, 16, 11, 0.3, 4.4); c.stroke();
    c.strokeStyle = "#8a50ff";
    c.beginPath(); c.arc(16, 16, 7, 3.4, 7.2); c.stroke();
    dot(c, 16, 16, 5, "#07040f");
  },
  speed: (c) => {
    c.strokeStyle = "#5bd6ff";
    c.lineWidth = 3.5;
    c.lineCap = "round";
    for (let i = 0; i < 2; i++) {
      c.beginPath();
      c.moveTo(7 + i * 9, 6); c.lineTo(15 + i * 9, 16); c.lineTo(7 + i * 9, 26);
      c.stroke();
    }
  },
  heavy: (c) => {
    poly(c, [9, 8, 23, 8, 28, 28, 4, 28], "#ff6b6b");
    poly(c, [9, 8, 23, 8, 24, 13, 8, 13], "#ffa0a0");
    dot(c, 16, 6, 3, "#ffd0d0");
    c.fillStyle = "#3a0d0d";
    c.font = "bold 10px sans-serif";
    c.textAlign = "center";
    c.fillText("KG", 16, 24);
  },
  homing: (c) => {
    c.strokeStyle = "#7dff9a";
    c.lineWidth = 2;
    c.beginPath(); c.arc(16, 16, 10, 0, 7); c.stroke();
    c.beginPath(); c.arc(16, 16, 5, 0, 7); c.stroke();
    c.beginPath();
    c.moveTo(16, 1); c.lineTo(16, 7); c.moveTo(16, 25); c.lineTo(16, 31);
    c.moveTo(1, 16); c.lineTo(7, 16); c.moveTo(25, 16); c.lineTo(31, 16);
    c.stroke();
    dot(c, 16, 16, 2, "#fff");
  },
  rubber: (c) => {
    c.strokeStyle = "#ff9ad5";
    c.lineWidth = 2.5;
    c.beginPath();
    c.moveTo(3, 26); c.lineTo(11, 8); c.lineTo(19, 24); c.lineTo(27, 6);
    c.stroke();
    dot(c, 27, 6, 3.5, "#ffd0ec");
  },
  pierce: (c) => {
    poly(c, [28, 16, 18, 9, 18, 13, 3, 13, 3, 19, 18, 19, 18, 23], "#ffd166");
    c.strokeStyle = "#fff";
    c.lineWidth = 2;
    c.beginPath(); c.moveTo(12, 3); c.lineTo(12, 29); c.stroke();
  },
  trail: (c) => {
    glow(c, 20, 14, 12, "rgba(255,120,40,.5)");
    for (let i = 0; i < 4; i++) dot(c, 5 + i * 6, 24 - i * 4, 2 + i * 1.2, i < 3 ? "#ff8a3d" : "#ffd24d");
  },
  wavy: (c) => {
    c.strokeStyle = "#9fb4ff";
    c.lineWidth = 3;
    c.lineCap = "round";
    c.beginPath();
    for (let x = 3; x <= 29; x++) {
      const y = 16 + Math.sin((x - 3) / 4) * 7;
      if (x === 3) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.stroke();
    dot(c, 29, 16 + Math.sin(26 / 4) * 7, 3, "#fff");
  },
  quick: (c) => {
    c.strokeStyle = "#fff";
    c.lineWidth = 2.5;
    c.beginPath(); c.arc(16, 17, 11, 0, 7); c.stroke();
    c.beginPath(); c.moveTo(16, 17); c.lineTo(16, 9); c.moveTo(16, 17); c.lineTo(22, 20); c.stroke();
    c.fillStyle = "#fff";
    c.fillRect(13, 2, 6, 3);
  },
  recharge: (c) => {
    c.strokeStyle = "#d0d0ff";
    c.lineWidth = 3;
    c.beginPath(); c.arc(16, 16, 10, 0.6, 5.2); c.stroke();
    poly(c, [25, 4, 27, 15, 16, 12], "#d0d0ff");
  },
  double: (c) => {
    glow(c, 10, 16, 8, "rgba(200,140,255,.6)");
    glow(c, 22, 16, 8, "rgba(200,140,255,.6)");
    dot(c, 10, 16, 5, "#d9a8ff");
    dot(c, 22, 16, 5, "#d9a8ff");
    dot(c, 10, 16, 2, "#fff");
    dot(c, 22, 16, 2, "#fff");
  },
  triple: (c) => {
    for (const [x, y] of [[8, 22], [24, 22], [16, 8]]) {
      glow(c, x, y, 8, "rgba(200,140,255,.6)");
      dot(c, x, y, 4.5, "#e0b6ff");
      dot(c, x, y, 1.8, "#fff");
    }
  },
  scatter: (c) => {
    c.strokeStyle = "#e48bff";
    c.lineWidth = 2;
    for (let i = -2; i <= 2; i++) {
      const a = -Math.PI / 2 + i * 0.4;
      c.beginPath();
      c.moveTo(16, 27);
      c.lineTo(16 + Math.cos(a) * 22, 27 + Math.sin(a) * 22);
      c.stroke();
      dot(c, 16 + Math.cos(a) * 22, 27 + Math.sin(a) * 22, 2.5, "#fff");
    }
  },
  trigger: (c) => {
    dot(c, 7, 16, 4, "#3de0a0");
    c.strokeStyle = "#3de0a0";
    c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(11, 16); c.lineTo(18, 16); c.stroke();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      c.beginPath();
      c.moveTo(23 + Math.cos(a) * 3, 16 + Math.sin(a) * 3);
      c.lineTo(23 + Math.cos(a) * 8, 16 + Math.sin(a) * 8);
      c.stroke();
    }
    dot(c, 23, 16, 2.5, "#fff");
  },
  timer: (c) => {
    dot(c, 16, 17, 11, "#124a46");
    c.strokeStyle = "#2fd0c0";
    c.lineWidth = 2.5;
    c.beginPath(); c.arc(16, 17, 11, 0, 7); c.stroke();
    c.beginPath(); c.moveTo(16, 17); c.lineTo(16, 9); c.moveTo(16, 17); c.lineTo(21, 20); c.stroke();
    c.fillStyle = "#2fd0c0";
    c.fillRect(13, 2, 6, 3);
  },
};

export function getIcon(id: string): HTMLCanvasElement {
  let cv = cache[id];
  if (cv) return cv;
  cv = document.createElement("canvas");
  cv.width = 32;
  cv.height = 32;
  const c = cv.getContext("2d")!;
  c.lineCap = "round";
  c.lineJoin = "round";
  (drawers[id] || drawers.spark)(c);
  cache[id] = cv;
  return cv;
}

export function iconURL(id: string): string {
  return urlCache[id] || (urlCache[id] = getIcon(id).toDataURL());
}
