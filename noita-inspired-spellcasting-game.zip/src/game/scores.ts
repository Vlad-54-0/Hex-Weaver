export interface ScoreEntry {
  name: string;
  score: number;
  wave: number;
  kills: number;
  date: number;
}

const KEY = "hexweaver:scores:v1";
const NAME_KEY = "hexweaver:name";

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as ScoreEntry[];
    return Array.isArray(arr) ? arr.slice(0, 10) : [];
  } catch {
    return [];
  }
}

/** Adds an entry and returns its rank index (or -1 if it didn't make the table). */
export function addScore(e: ScoreEntry): { scores: ScoreEntry[]; rank: number } {
  const scores = loadScores();
  scores.push(e);
  scores.sort((a, b) => b.score - a.score || a.date - b.date);
  const top = scores.slice(0, 10);
  const rank = top.indexOf(e);
  try {
    localStorage.setItem(KEY, JSON.stringify(top));
  } catch {
    /* ignore */
  }
  return { scores: top, rank };
}

export function loadName(): string {
  try {
    return localStorage.getItem(NAME_KEY) || "WIZ";
  } catch {
    return "WIZ";
  }
}

export function saveName(n: string) {
  try {
    localStorage.setItem(NAME_KEY, n);
  } catch {
    /* ignore */
  }
}
