// Spell data + Noita-style wand evaluation (modifiers, multicast, trigger, timer)

export type SpellKind = "proj" | "mod" | "multi" | "trigger" | "timer";
export type Fx = "none" | "fire" | "frost" | "shock";
export type Shape = "orb" | "bolt" | "bomb" | "shard" | "hole";

export interface ProjDef {
  speed: number;
  dmg: number;
  life: number;
  radius: number;
  color: string;
  fx: Fx;
  shape: Shape;
  explode?: { r: number; dmg: number };
  bounce?: number;
  noHit?: boolean;
  drag?: number;
  chain?: number;
  blackhole?: boolean;
  sound: "spark" | "fire" | "frost" | "zap" | "bomb" | "hole" | "bounce";
}

export interface Mods {
  speed: number;
  damage: number;
  homing: number;
  bounce: number;
  pierce: number;
  trail: number;
  wavy: number;
  names: string[];
}

export interface SpellDef {
  id: string;
  name: string;
  kind: SpellKind;
  color: string;
  desc: string;
  mana: number;
  delay?: number;
  recharge?: number;
  proj?: ProjDef;
  mod?: Partial<Mods> & { label?: string };
  count?: number;
  spread?: number;
  scatter?: boolean;
  timer?: number;
  minWave: number;
  weight: number;
}

export const KIND_LABEL: Record<SpellKind, string> = {
  proj: "PROJECTILE",
  mod: "MODIFIER",
  multi: "MULTICAST",
  trigger: "TRIGGER",
  timer: "TIMER",
};

export const KIND_COLOR: Record<SpellKind, string> = {
  proj: "#ff7a45",
  mod: "#4aa8ff",
  multi: "#b86bff",
  trigger: "#3de0a0",
  timer: "#3de0a0",
};

const list: SpellDef[] = [
  // ---------- projectiles
  {
    id: "spark", name: "Spark Bolt", kind: "proj", color: "#7ff", mana: 4, delay: -0.03,
    desc: "Fast, cheap arcane bolt. The bread and butter.",
    minWave: 0, weight: 10,
    proj: { speed: 640, dmg: 4, life: 0.9, radius: 4, color: "#7ff", fx: "none", shape: "bolt", sound: "spark" },
  },
  {
    id: "fireball", name: "Fireball", kind: "proj", color: "#ffa033", mana: 18, delay: 0.14,
    desc: "Explodes on impact. Sets enemies ablaze.",
    minWave: 0, weight: 8,
    proj: { speed: 360, dmg: 5, life: 1.4, radius: 7, color: "#ff9a2e", fx: "fire", shape: "orb", explode: { r: 58, dmg: 10 }, sound: "fire" },
  },
  {
    id: "frost", name: "Frost Shard", kind: "proj", color: "#8df", mana: 7,
    desc: "3 hits freeze. Frozen foes shatter under heavy hits & blasts.",
    minWave: 0, weight: 8,
    proj: { speed: 520, dmg: 4, life: 1, radius: 5, color: "#9cf", fx: "frost", shape: "shard", sound: "frost" },
  },
  {
    id: "lightning", name: "Lightning Bolt", kind: "proj", color: "#ffee55", mana: 11, delay: 0.04,
    desc: "Blazing fast. Arcs to 2 nearby foes. Burning + shock = OVERLOAD.",
    minWave: 1, weight: 7,
    proj: { speed: 1000, dmg: 7, life: 0.35, radius: 5, color: "#ffee55", fx: "shock", shape: "bolt", chain: 2, sound: "zap" },
  },
  {
    id: "bounce", name: "Bouncing Burst", kind: "proj", color: "#ff66cc", mana: 6,
    desc: "Ricochets off walls and enemies 4 times.",
    minWave: 0, weight: 8,
    proj: { speed: 440, dmg: 4, life: 2.6, radius: 6, color: "#ff66cc", fx: "none", shape: "orb", bounce: 4, sound: "bounce" },
  },
  {
    id: "bomb", name: "Bomb", kind: "proj", color: "#cfd3dd", mana: 22, delay: 0.2,
    desc: "Slides to a stop, then goes BOOM. Big blast.",
    minWave: 2, weight: 5,
    proj: { speed: 280, dmg: 0, life: 1.1, radius: 8, color: "#cfd3dd", fx: "none", shape: "bomb", noHit: true, drag: 2.2, bounce: 3, explode: { r: 98, dmg: 34 }, sound: "bomb" },
  },
  {
    id: "blackhole", name: "Black Hole", kind: "proj", color: "#a66bff", mana: 38, delay: 0.35,
    desc: "Drifts slowly, sucking enemies in. Collapses violently.",
    minWave: 4, weight: 3,
    proj: { speed: 130, dmg: 0, life: 2.4, radius: 12, color: "#a66bff", fx: "none", shape: "hole", noHit: true, bounce: 99, blackhole: true, explode: { r: 115, dmg: 32 }, sound: "hole" },
  },

  // ---------- modifiers
  {
    id: "speed", name: "Speed Up", kind: "mod", color: "#5bd6ff", mana: 3, delay: -0.02,
    desc: "Next projectile flies 70% faster.",
    minWave: 0, weight: 6, mod: { speed: 1.7, label: "Fast" },
  },
  {
    id: "heavy", name: "Heavy Shot", kind: "mod", color: "#ff6b6b", mana: 6, delay: 0.08,
    desc: "+6 damage, slower. Heavy hits SHATTER frozen foes.",
    minWave: 0, weight: 6, mod: { damage: 6, speed: 0.72, label: "Heavy" },
  },
  {
    id: "homing", name: "Homing", kind: "mod", color: "#7dff9a", mana: 6, delay: 0.03,
    desc: "Next projectile steers toward enemies.",
    minWave: 0, weight: 7, mod: { homing: 1, label: "Homing" },
  },
  {
    id: "rubber", name: "Rubber Shot", kind: "mod", color: "#ff9ad5", mana: 3,
    desc: "+3 bounces for the next projectile.",
    minWave: 1, weight: 5, mod: { bounce: 3, label: "Rubber" },
  },
  {
    id: "pierce", name: "Piercing", kind: "mod", color: "#ffd166", mana: 5, delay: 0.02,
    desc: "Next projectile passes through 3 enemies.",
    minWave: 1, weight: 6, mod: { pierce: 3, label: "Piercing" },
  },
  {
    id: "trail", name: "Fire Trail", kind: "mod", color: "#ff8a3d", mana: 6,
    desc: "Leaves burning embers along its path.",
    minWave: 1, weight: 5, mod: { trail: 1, label: "Blazing" },
  },
  {
    id: "wavy", name: "Wavy Shot", kind: "mod", color: "#9fb4ff", mana: 2,
    desc: "Next projectile snakes through the air.",
    minWave: 1, weight: 4, mod: { wavy: 1, label: "Wavy" },
  },
  {
    id: "quick", name: "Quick Cast", kind: "mod", color: "#ffffff", mana: 3, delay: -0.1,
    desc: "Cast delay -0.10s. Applies to the whole cast.",
    minWave: 1, weight: 5, mod: { label: "Quick" },
  },
  {
    id: "recharge", name: "Fast Recharge", kind: "mod", color: "#d0d0ff", mana: 5, recharge: -0.25,
    desc: "Wand recharge -0.25s when the cycle wraps.",
    minWave: 1, weight: 4, mod: { label: "Recharged" },
  },

  // ---------- multicast
  {
    id: "double", name: "Double Spell", kind: "multi", color: "#c58bff", mana: 2, delay: 0.04, count: 2, spread: 0.1,
    desc: "Casts the next 2 spells at once.",
    minWave: 0, weight: 8,
  },
  {
    id: "triple", name: "Triple Spell", kind: "multi", color: "#d9a0ff", mana: 4, delay: 0.07, count: 3, spread: 0.16,
    desc: "Casts the next 3 spells at once.",
    minWave: 2, weight: 5,
  },
  {
    id: "scatter", name: "Scatter Spell", kind: "multi", color: "#e48bff", mana: 3, delay: -0.02, count: 3, spread: 0.5, scatter: true,
    desc: "Casts the next 3 spells in a wild spread.",
    minWave: 1, weight: 5,
  },

  // ---------- trigger / timer
  {
    id: "trigger", name: "Trigger", kind: "trigger", color: "#3de0a0", mana: 3,
    desc: "Next projectile carries the one after it. Payload fires on impact.",
    minWave: 1, weight: 7,
  },
  {
    id: "timer", name: "Timer", kind: "timer", color: "#2fd0c0", mana: 3, timer: 0.55,
    desc: "Next projectile casts the one after it 0.55s into flight.",
    minWave: 2, weight: 5,
  },
];

export const SPELLS: Record<string, SpellDef> = Object.fromEntries(list.map((s) => [s.id, s]));
export const SPELL_LIST = list;

export interface Shot {
  spell: SpellDef;
  mods: Mods;
  offset: number;
  payload?: Shot[];
  payloadType?: "hit" | "timer";
  timer?: number;
}

export interface CastResult {
  empty: boolean;
  shots: Shot[];
  start: number; // compact index range consumed [start,end)
  end: number;
  next: number;
  wrapped: boolean;
  mana: number;
  cooldown: number;
}

export const BASE_DELAY = 0.15;
export const BASE_RECHARGE = 0.42;

const BASE_MODS: Mods = { speed: 1, damage: 0, homing: 0, bounce: 0, pierce: 0, trail: 0, wavy: 0, names: [] };

function mergeMods(a: Mods, d: SpellDef): Mods {
  const m = d.mod || {};
  return {
    speed: a.speed * (m.speed ?? 1),
    damage: a.damage + (m.damage ?? 0),
    homing: a.homing + (m.homing ?? 0),
    bounce: a.bounce + (m.bounce ?? 0),
    pierce: a.pierce + (m.pierce ?? 0),
    trail: a.trail + (m.trail ?? 0),
    wavy: a.wavy + (m.wavy ?? 0),
    names: m.label ? [...a.names, m.label] : a.names,
  };
}

export function compact(slots: (string | null)[]): SpellDef[] {
  const out: SpellDef[] = [];
  for (const id of slots) if (id && SPELLS[id]) out.push(SPELLS[id]);
  return out;
}

export function evalCast(slots: (string | null)[], ptrIn: number): CastResult {
  const spells = compact(slots);
  const len = spells.length;
  if (!len) return { empty: true, shots: [], start: 0, end: 0, next: 0, wrapped: true, mana: 0, cooldown: 0.2 };
  let ptr = ptrIn >= len ? 0 : ptrIn;
  const start = ptr;
  let mana = 0;
  let delay = BASE_DELAY;
  let recharge = BASE_RECHARGE;

  const draw = (n: number, modsIn: Mods): Shot[] => {
    let mods = modsIn;
    const out: Shot[] = [];
    while (n > 0 && ptr < len) {
      const s = spells[ptr++];
      mana += s.mana;
      delay += s.delay ?? 0;
      recharge += s.recharge ?? 0;
      if (s.kind === "mod") {
        mods = mergeMods(mods, s);
      } else if (s.kind === "proj") {
        out.push({ spell: s, mods, offset: 0 });
        n--;
      } else if (s.kind === "multi") {
        const inner = draw(s.count || 2, mods);
        const c = inner.length;
        inner.forEach((sh, i) => {
          if (s.scatter) sh.offset += (Math.random() * 2 - 1) * (s.spread || 0.4);
          else sh.offset += (i - (c - 1) / 2) * (s.spread || 0.1);
        });
        out.push(...inner);
        n--;
      } else {
        const carriers = draw(1, mods);
        const payload = draw(1, BASE_MODS);
        if (carriers.length && payload.length) {
          for (const c of carriers) {
            c.payload = payload;
            c.payloadType = s.kind === "timer" ? "timer" : "hit";
            c.timer = s.timer;
          }
        }
        out.push(...carriers);
        n--;
      }
    }
    return out;
  };

  const shots = draw(1, BASE_MODS);
  const wrapped = ptr >= len;
  delay = Math.max(0.05, delay);
  recharge = Math.max(0.08, recharge);
  return {
    empty: false,
    shots,
    start,
    end: ptr,
    next: wrapped ? 0 : ptr,
    wrapped,
    mana,
    cooldown: wrapped ? Math.max(delay, recharge) : delay,
  };
}

export function shotLabel(s: Shot): string {
  let t = `${s.mods.names.join(" ")} ${s.spell.name}`.trim();
  if (s.payload) {
    const p = s.payload.map(shotLabel).join(" + ");
    t += s.payloadType === "timer" ? ` ⏱ [${p}]` : ` ⇒ [${p}]`;
  }
  return t;
}

export interface WandInfo {
  casts: { labels: string[]; mana: number; time: number }[];
  cycleTime: number;
  totalMana: number;
}

export function describeWand(slots: (string | null)[]): WandInfo {
  const casts: WandInfo["casts"] = [];
  let ptr = 0;
  let cycleTime = 0;
  let totalMana = 0;
  for (let i = 0; i < 24; i++) {
    const r = evalCast(slots, ptr);
    if (r.empty) break;
    casts.push({ labels: r.shots.map(shotLabel), mana: r.mana, time: r.cooldown });
    cycleTime += r.cooldown;
    totalMana += r.mana;
    if (r.wrapped) break;
    ptr = r.next;
  }
  return { casts, cycleTime, totalMana };
}

export const START_WAND: (string | null)[] = ["spark", "spark", "double", "spark", "fireball"];

export function pickOffers(wave: number): string[] {
  const avail = list.filter((s) => s.minWave <= wave);
  const pick = (pool: SpellDef[], exclude: string[]) => {
    const p = pool.filter((s) => !exclude.includes(s.id));
    const total = p.reduce((a, s) => a + s.weight, 0);
    let r = Math.random() * total;
    for (const s of p) {
      r -= s.weight;
      if (r <= 0) return s.id;
    }
    return p[p.length - 1].id;
  };
  const out: string[] = [];
  out.push(pick(avail.filter((s) => s.kind === "proj"), out));
  out.push(pick(avail.filter((s) => s.kind === "mod" || s.kind === "multi"), out));
  out.push(pick(avail, out));
  // shuffle
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
