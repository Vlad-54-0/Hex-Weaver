// World geometry, collision helpers, and the baked cave background.

export const W = 1500;
export const H = 1000;
export const RIM = 66;

export const PILLARS = [
  { x: 420, y: 300, r: 44 },
  { x: 1080, y: 300, r: 44 },
  { x: 420, y: 700, r: 44 },
  { x: 1080, y: 700, r: 44 },
  { x: 750, y: 190, r: 32 },
  { x: 750, y: 810, r: 32 },
  { x: 215, y: 500, r: 30 },
  { x: 1285, y: 500, r: 30 },
];

export const WH = { nx: 0, ny: 0, px: 0, py: 0 };

/** Circle (x,y,r) vs world. On hit fills WH with normal + corrected position. */
export function wallHit(x: number, y: number, r: number): boolean {
  let hit = false;
  let cx = x;
  let cy = y;
  let nx = 0;
  let ny = 0;
  if (cx < RIM + r) { cx = RIM + r; nx = 1; hit = true; }
  else if (cx > W - RIM - r) { cx = W - RIM - r; nx = -1; hit = true; }
  if (cy < RIM + r) { cy = RIM + r; ny = 1; hit = true; }
  else if (cy > H - RIM - r) { cy = H - RIM - r; ny = -1; hit = true; }
  for (let i = 0; i < PILLARS.length; i++) {
    const p = PILLARS[i];
    const dx = cx - p.x;
    const dy = cy - p.y;
    const rr = p.r + r;
    const d2 = dx * dx + dy * dy;
    if (d2 < rr * rr) {
      const d = Math.sqrt(d2) || 0.001;
      nx = dx / d;
      ny = dy / d;
      cx = p.x + nx * rr;
      cy = p.y + ny * rr;
      hit = true;
    }
  }
  if (hit) {
    const l = Math.hypot(nx, ny);
    WH.px = cx;
    WH.py = cy;
    if (l < 0.0001) {
      WH.nx = 1;
      WH.ny = 0;
    } else {
      WH.nx = nx / l;
      WH.ny = ny / l;
    }
  }
  return hit;
}

function mulberry(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function bakeBackground(): HTMLCanvasElement {
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const c = cv.getContext("2d")!;
  const rnd = mulberry(1337);

  // floor
  c.fillStyle = "#15122200";
  c.fillStyle = "#151222";
  c.fillRect(0, 0, W, H);
  const T = 50;
  for (let y = 0; y < H; y += T) {
    for (let x = 0; x < W; x += T) {
      const v = rnd();
      c.fillStyle = v < 0.5 ? `rgba(120,100,200,${(v * 0.07).toFixed(3)})` : `rgba(0,0,0,${((v - 0.5) * 0.25).toFixed(3)})`;
      c.fillRect(x, y, T, T);
    }
  }
  c.strokeStyle = "rgba(0,0,0,.35)";
  c.lineWidth = 2;
  for (let y = 0; y <= H; y += T) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
  for (let x = 0; x <= W; x += T) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); }
  c.strokeStyle = "rgba(150,130,255,.05)";
  c.lineWidth = 1;
  for (let y = 1; y <= H; y += T) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }

  // speckle
  for (let i = 0; i < 2600; i++) {
    const x = rnd() * W;
    const y = rnd() * H;
    c.fillStyle = rnd() < 0.5 ? "rgba(0,0,0,.35)" : "rgba(170,150,255,.08)";
    c.fillRect(x, y, 2 + rnd() * 3, 2 + rnd() * 3);
  }
  // cracks
  c.strokeStyle = "rgba(0,0,0,.4)";
  c.lineWidth = 1.5;
  for (let i = 0; i < 40; i++) {
    let x = rnd() * W;
    let y = rnd() * H;
    c.beginPath();
    c.moveTo(x, y);
    for (let k = 0; k < 5; k++) {
      x += (rnd() - 0.5) * 40;
      y += (rnd() - 0.5) * 40;
      c.lineTo(x, y);
    }
    c.stroke();
  }

  // central rune circle
  c.save();
  c.translate(W / 2, H / 2);
  c.strokeStyle = "rgba(90,200,200,.14)";
  c.lineWidth = 3;
  for (const r of [120, 150, 200]) {
    c.beginPath();
    c.arc(0, 0, r, 0, Math.PI * 2);
    c.stroke();
  }
  c.strokeStyle = "rgba(180,110,255,.14)";
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    c.beginPath();
    c.moveTo(Math.cos(a) * 150, Math.sin(a) * 150);
    c.lineTo(Math.cos(a) * 200, Math.sin(a) * 200);
    c.stroke();
  }
  c.beginPath();
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
    const x = Math.cos(a) * 120;
    const y = Math.sin(a) * 120;
    if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
  }
  c.closePath();
  c.stroke();
  c.restore();

  // inner shadow near rim
  const edge = 110;
  const sh = (x0: number, y0: number, x1: number, y1: number, rx: number, ry: number, rw: number, rh: number) => {
    const g = c.createLinearGradient(x0, y0, x1, y1);
    g.addColorStop(0, "rgba(0,0,0,.6)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    c.fillStyle = g;
    c.fillRect(rx, ry, rw, rh);
  };
  sh(0, RIM, 0, RIM + edge, 0, RIM, W, edge);
  sh(0, H - RIM, 0, H - RIM - edge, 0, H - RIM - edge, W, edge);
  sh(RIM, 0, RIM + edge, 0, RIM, 0, edge, H);
  sh(W - RIM, 0, W - RIM - edge, 0, W - RIM - edge, 0, edge, H);

  // rim rock
  c.fillStyle = "#0a0813";
  c.beginPath();
  c.rect(0, 0, W, H);
  c.rect(RIM, RIM, W - RIM * 2, H - RIM * 2);
  c.fill("evenodd");
  for (let i = 0; i < 520; i++) {
    const side = Math.floor(rnd() * 4);
    let x = 0;
    let y = 0;
    const d = rnd() * (RIM + 4);
    if (side === 0) { x = rnd() * W; y = d; }
    else if (side === 1) { x = rnd() * W; y = H - d; }
    else if (side === 2) { x = d; y = rnd() * H; }
    else { x = W - d; y = rnd() * H; }
    const r = 6 + rnd() * 18;
    const l = 14 + rnd() * 16;
    c.fillStyle = `rgb(${l},${l - 2},${l + 14})`;
    c.beginPath();
    c.arc(x, y, r, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "rgba(160,140,255,.07)";
    c.beginPath();
    c.arc(x - r * 0.25, y - r * 0.25, r * 0.6, 0, Math.PI * 2);
    c.fill();
  }
  // dark margin outside edge for crisp border
  c.strokeStyle = "rgba(140,110,255,.45)";
  c.lineWidth = 3;
  c.strokeRect(RIM, RIM, W - RIM * 2, H - RIM * 2);
  c.strokeStyle = "rgba(0,0,0,.6)";
  c.lineWidth = 6;
  c.strokeRect(RIM - 4, RIM - 4, W - RIM * 2 + 8, H - RIM * 2 + 8);

  // pillars
  for (const p of PILLARS) {
    c.fillStyle = "rgba(0,0,0,.45)";
    c.beginPath();
    c.ellipse(p.x + 6, p.y + 10, p.r + 6, p.r * 0.9, 0, 0, Math.PI * 2);
    c.fill();
    const g = c.createRadialGradient(p.x - p.r * 0.3, p.y - p.r * 0.3, 2, p.x, p.y, p.r);
    g.addColorStop(0, "#3a3452");
    g.addColorStop(1, "#16121f");
    c.fillStyle = g;
    c.beginPath();
    for (let a = 0; a < 20; a++) {
      const ang = (a / 20) * Math.PI * 2;
      const rr = p.r * (0.92 + rnd() * 0.12);
      const x = p.x + Math.cos(ang) * rr;
      const y = p.y + Math.sin(ang) * rr;
      if (a === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
    c.fill();
    c.strokeStyle = "rgba(170,150,255,.35)";
    c.lineWidth = 2;
    c.stroke();
    for (let k = 0; k < 4; k++) {
      c.fillStyle = "rgba(0,0,0,.25)";
      c.beginPath();
      c.arc(p.x + (rnd() - 0.5) * p.r, p.y + (rnd() - 0.5) * p.r, 3 + rnd() * 5, 0, Math.PI * 2);
      c.fill();
    }
  }

  // glowing crystals embedded in the rim
  const cols = ["#3fe0d0", "#d65bff", "#ffb347", "#5b9bff"];
  c.globalCompositeOperation = "lighter";
  for (let i = 0; i < 26; i++) {
    const side = Math.floor(rnd() * 4);
    let x = 0;
    let y = 0;
    if (side === 0) { x = 100 + rnd() * (W - 200); y = RIM - 6; }
    else if (side === 1) { x = 100 + rnd() * (W - 200); y = H - RIM + 6; }
    else if (side === 2) { x = RIM - 6; y = 100 + rnd() * (H - 200); }
    else { x = W - RIM + 6; y = 100 + rnd() * (H - 200); }
    const col = cols[Math.floor(rnd() * cols.length)];
    const g = c.createRadialGradient(x, y, 0, x, y, 70);
    g.addColorStop(0, col + "55");
    g.addColorStop(1, col + "00");
    c.fillStyle = g;
    c.fillRect(x - 70, y - 70, 140, 140);
    c.fillStyle = col;
    c.beginPath();
    c.moveTo(x, y - 10);
    c.lineTo(x + 5, y);
    c.lineTo(x, y + 8);
    c.lineTo(x - 5, y);
    c.fill();
  }
  c.globalCompositeOperation = "source-over";
  return cv;
}
