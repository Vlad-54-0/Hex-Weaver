// Unified keyboard / mouse / touch input.

export interface Stick {
  id: number;
  ox: number;
  oy: number;
  kx: number; // knob px offset
  ky: number;
  x: number; // normalized
  y: number;
  active: boolean;
}

const mkStick = (): Stick => ({ id: -1, ox: 0, oy: 0, kx: 0, ky: 0, x: 0, y: 0, active: false });

export const STICK_R = 54;
export const DASH_R = 34;

export interface InputHooks {
  onPause(): void;
  onRestart(): void;
  onMute(): void;
  onConfirm(): void;
  onGesture(): void;
  size(): { w: number; h: number };
}

export class Input {
  keys = new Set<string>();
  mouse = { x: 0, y: 0, down: false, seen: false };
  touchMode = false;
  move = mkStick();
  aim = mkStick();
  dashQueued = false;
  dashTouchId = -1;
  dashHeld = false;

  constructor(private canvas: HTMLCanvasElement, private hooks: InputHooks) {
    window.addEventListener("keydown", this.kd);
    window.addEventListener("keyup", this.ku);
    window.addEventListener("blur", this.reset);
    canvas.addEventListener("pointerdown", this.pd);
    canvas.addEventListener("pointermove", this.pm);
    canvas.addEventListener("pointerup", this.pu);
    canvas.addEventListener("pointercancel", this.pu);
    canvas.addEventListener("contextmenu", this.cm);
  }

  destroy() {
    window.removeEventListener("keydown", this.kd);
    window.removeEventListener("keyup", this.ku);
    window.removeEventListener("blur", this.reset);
    this.canvas.removeEventListener("pointerdown", this.pd);
    this.canvas.removeEventListener("pointermove", this.pm);
    this.canvas.removeEventListener("pointerup", this.pu);
    this.canvas.removeEventListener("pointercancel", this.pu);
    this.canvas.removeEventListener("contextmenu", this.cm);
  }

  reset = () => {
    this.keys.clear();
    this.mouse.down = false;
    for (const s of [this.move, this.aim]) {
      s.active = false; s.id = -1; s.x = 0; s.y = 0; s.kx = 0; s.ky = 0;
    }
    this.dashTouchId = -1;
    this.dashHeld = false;
  };

  dashBtn() {
    const { w, h } = this.hooks.size();
    return { x: w - 56, y: h - 64, r: DASH_R };
  }

  private kd = (e: KeyboardEvent) => {
    const t = e.target as HTMLElement | null;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) {
      if (e.code === "Enter") this.hooks.onConfirm();
      return;
    }
    this.hooks.onGesture();
    this.touchMode = false;
    const code = e.code;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Tab"].includes(code)) e.preventDefault();
    if (e.repeat) return;
    this.keys.add(code);
    if (code === "Space" || code === "ShiftLeft" || code === "ShiftRight") {
      this.dashQueued = true;
      if (code === "Space") this.hooks.onConfirm();
    }
    if (code === "Escape" || code === "KeyP") this.hooks.onPause();
    if (code === "KeyR") this.hooks.onRestart();
    if (code === "KeyM") this.hooks.onMute();
    if (code === "Enter") this.hooks.onConfirm();
  };

  private ku = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private cm = (e: Event) => e.preventDefault();

  private pos(e: PointerEvent) {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  private pd = (e: PointerEvent) => {
    this.hooks.onGesture();
    const p = this.pos(e);
    if (e.pointerType === "mouse") {
      this.mouse.x = p.x;
      this.mouse.y = p.y;
      this.mouse.seen = true;
      this.touchMode = false;
      if (e.button === 2) this.dashQueued = true;
      else if (e.button === 0) this.mouse.down = true;
      return;
    }
    this.touchMode = true;
    this.canvas.setPointerCapture?.(e.pointerId);
    const { w } = this.hooks.size();
    const db = this.dashBtn();
    if (Math.hypot(p.x - db.x, p.y - db.y) < db.r + 14 && this.dashTouchId < 0) {
      this.dashTouchId = e.pointerId;
      this.dashQueued = true;
      this.dashHeld = true;
      return;
    }
    const s = p.x < w * 0.5 ? this.move : this.aim;
    if (s.active) return;
    s.active = true;
    s.id = e.pointerId;
    s.ox = p.x;
    s.oy = p.y;
    s.kx = s.ky = s.x = s.y = 0;
  };

  private pm = (e: PointerEvent) => {
    const p = this.pos(e);
    if (e.pointerType === "mouse") {
      this.mouse.x = p.x;
      this.mouse.y = p.y;
      this.mouse.seen = true;
      this.touchMode = false;
      return;
    }
    for (const s of [this.move, this.aim]) {
      if (s.active && s.id === e.pointerId) {
        let dx = p.x - s.ox;
        let dy = p.y - s.oy;
        const d = Math.hypot(dx, dy);
        if (d > STICK_R) {
          // drag the base along so the stick feels floating
          const over = d - STICK_R;
          s.ox += (dx / d) * over;
          s.oy += (dy / d) * over;
          dx = p.x - s.ox;
          dy = p.y - s.oy;
        }
        s.kx = dx;
        s.ky = dy;
        s.x = dx / STICK_R;
        s.y = dy / STICK_R;
      }
    }
  };

  private pu = (e: PointerEvent) => {
    if (e.pointerType === "mouse") {
      if (e.button === 0) this.mouse.down = false;
      return;
    }
    if (e.pointerId === this.dashTouchId) {
      this.dashTouchId = -1;
      this.dashHeld = false;
    }
    for (const s of [this.move, this.aim]) {
      if (s.active && s.id === e.pointerId) {
        s.active = false; s.id = -1; s.x = s.y = s.kx = s.ky = 0;
      }
    }
  };

  // --- derived state
  moveVec(out: { x: number; y: number }) {
    let x = 0;
    let y = 0;
    const k = this.keys;
    if (k.has("KeyA")) x -= 1;
    if (k.has("KeyD")) x += 1;
    if (k.has("KeyW")) y -= 1;
    if (k.has("KeyS")) y += 1;
    if (this.move.active) {
      const m = Math.hypot(this.move.x, this.move.y);
      if (m > 0.12) {
        x += this.move.x;
        y += this.move.y;
      }
    }
    const l = Math.hypot(x, y);
    if (l > 1) { x /= l; y /= l; }
    out.x = x;
    out.y = y;
  }

  arrowAim(out: { x: number; y: number }): boolean {
    const k = this.keys;
    let x = 0;
    let y = 0;
    if (k.has("ArrowLeft")) x -= 1;
    if (k.has("ArrowRight")) x += 1;
    if (k.has("ArrowUp")) y -= 1;
    if (k.has("ArrowDown")) y += 1;
    out.x = x;
    out.y = y;
    return x !== 0 || y !== 0;
  }
}
