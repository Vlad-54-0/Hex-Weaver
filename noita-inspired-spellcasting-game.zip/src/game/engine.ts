import { sfx } from "./audio";
import { getIcon } from "./icons";
import { Input, STICK_R } from "./input";
import { BASE_DELAY, compact, evalCast, pickOffers, SPELLS, START_WAND, KIND_COLOR } from "./spells";
import type { Fx, ProjDef, Mods, Shot } from "./spells";
import { bakeBackground, H, RIM, W, WH, wallHit } from "./world";

export type Phase = "menu" | "playing" | "paused" | "altar" | "over";

export interface AltarData {
  offers: string[];
  wave: number;
  wand: (string | null)[];
  cap: number;
  newSlot: boolean;
  healed: number;
}
export interface OverData {
  score: number;
  wave: number;
  kills: number;
  bestCombo: number;
  time: number;
}
export interface Hooks {
  onPhase(p: Phase): void;
  onAltar(a: AltarData): void;
  onOver(r: OverData): void;
}

const TAU = Math.PI * 2;
const PR = 10; // player radius
const PSPEED = 215;
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => Math.atan2(Math.sin(b - a), Math.cos(b - a));

// ---------------------------------------------------------------- types
type EType = "slime" | "bat" | "jelly" | "spitter" | "brute";
interface EDef {
  r: number; hp: number; speed: number; dmg: number; pts: number;
  color: string; dark: string; cost: number; minWave: number; w: number; mass: number;
}
const ETYPES: Record<EType, EDef> = {
  slime: { r: 12, hp: 8, speed: 80, dmg: 10, pts: 10, color: "#4fdc6a", dark: "#1f7a38", cost: 1, minWave: 0, w: 10, mass: 1 },
  bat: { r: 9, hp: 4, speed: 150, dmg: 8, pts: 15, color: "#c070ff", dark: "#5b2a8c", cost: 1, minWave: 2, w: 6, mass: 0.7 },
  jelly: { r: 17, hp: 22, speed: 62, dmg: 12, pts: 25, color: "#45d4e8", dark: "#1a6a80", cost: 2, minWave: 3, w: 4, mass: 1.6 },
  spitter: { r: 12, hp: 14, speed: 72, dmg: 10, pts: 30, color: "#ffd24d", dark: "#8a6a10", cost: 2, minWave: 4, w: 4, mass: 1 },
  brute: { r: 22, hp: 55, speed: 52, dmg: 20, pts: 50, color: "#ff6a5a", dark: "#8a2a24", cost: 4, minWave: 3, w: 3, mass: 3.2 },
};

interface Enemy {
  type: EType; x: number; y: number; vx: number; vy: number; r: number; hp: number; maxHp: number;
  speed: number; dmg: number; pts: number; color: string; dark: string; mass: number;
  spawnT: number; burn: number; burnTick: number; chill: number; chillT: number; frozen: number; shock: number;
  flash: number; squash: number; phase: number; shootT: number; dead: boolean; mini: boolean;
}

interface Proj {
  x: number; y: number; vx: number; vy: number; pd: ProjDef; m: Mods; dmg: number; life: number; age: number;
  bounces: number; pierce: number; hit: Enemy[]; hitClear: number; payload?: Shot[]; ptype?: "hit" | "timer";
  ptimer: number; pfired: boolean; gen: number; trailT: number; homeT: number; target: Enemy | null;
  dead: boolean; tickT: number; spin: number;
}
interface EBullet { x: number; y: number; vx: number; vy: number; life: number; dmg: number }
interface Particle {
  x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; color: string;
  add: boolean; drag: number; grav: number; shrink: boolean;
}
interface Popup { x: number; y: number; vy: number; text: string; color: string; size: number; life: number; max: number }
interface Ring { x: number; y: number; r0: number; r1: number; life: number; max: number; color: string; width: number; flash: boolean }
interface Arc { pts: number[]; life: number; color: string }
interface Fire { x: number; y: number; life: number; tick: number }
interface Orb { x: number; y: number; vx: number; vy: number; life: number }

interface HurtOpts {
  fx?: Fx; explosion?: boolean; heavy?: boolean; quiet?: boolean; kx?: number; ky?: number; kb?: number; noReact?: boolean;
}

// glow sprite cache
const glowCache: Record<string, HTMLCanvasElement> = {};
function hexRgb(hex: string): [number, number, number] {
  let h = hex.replace("#", "");
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  const n = parseInt(h.slice(0, 6), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function glowSprite(color: string): HTMLCanvasElement {
  let c = glowCache[color];
  if (c) return c;
  c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const [r, gg, b] = hexRgb(color);
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, `rgba(${r},${gg},${b},0.95)`);
  grad.addColorStop(0.35, `rgba(${r},${gg},${b},0.35)`);
  grad.addColorStop(1, `rgba(${r},${gg},${b},0)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  glowCache[color] = c;
  return c;
}

export class Game {
  phase: Phase = "menu";
  private ctx: CanvasRenderingContext2D;
  private input: Input;
  private bg: HTMLCanvasElement;
  private raf = 0;
  private last = 0;
  private w = 0;
  private h = 0;
  private dpr = 1;
  private zoom = 1;
  private camX = 0;
  private camY = 0;
  private time = 0;

  // run state
  private player = this.newPlayer();
  private enemies: Enemy[] = [];
  private projs: Proj[] = [];
  private ebul: EBullet[] = [];
  private parts: Particle[] = [];
  private pool: Particle[] = [];
  private texts: Popup[] = [];
  private rings: Ring[] = [];
  private arcs: Arc[] = [];
  private fires: Fire[] = [];
  private orbs: Orb[] = [];

  wand: (string | null)[] = [...START_WAND];
  private wandCap = 5;
  private ptr = 0;
  private lastCast = { start: 0, end: 0, t: 0 };
  private nextColor = "#7ff";

  private wave = 0;
  private queue: EType[] = [];
  private spawnT = 0;
  private clearing = false;
  private clearT = 0;
  private vacuum = false;
  private score = 0;
  private shownScore = 0;
  private scorePunch = 0;
  private kills = 0;
  private combo = 0;
  private comboT = 0;
  private bestCombo = 0;
  private runTime = 0;
  private dead = false;
  private deadT = 0;
  private trauma = 0;
  private hitstop = 0;
  private timeScale = 1;
  private hurtFlash = 0;
  private whiteFlash = 0;
  private noMana = 0;
  private hpLag = 100;
  private banner = { text: "", sub: "", t: 0, max: 2, color: "#fff" };
  private hint = 0;
  private mv = { x: 0, y: 0 };
  private av = { x: 0, y: 0 };
  private emberT = 0;

  constructor(private canvas: HTMLCanvasElement, private hooks: Hooks) {
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.bg = bakeBackground();
    this.input = new Input(canvas, {
      onPause: () => this.togglePause(),
      onRestart: () => {
        if (this.phase === "paused" || this.phase === "over") this.startGame();
      },
      onMute: () => sfx.setMuted(!sfx.muted),
      onConfirm: () => {
        if (this.phase === "over" && this.deadT > 0.6) this.startGame();
        else if (this.phase === "menu") this.startGame();
      },
      onGesture: () => sfx.unlock(),
      size: () => ({ w: this.w, h: this.h }),
    });
    this.resize();
    this.resetRun();
    this.player.x = W / 2;
    this.player.y = H / 2;
    document.addEventListener("visibilitychange", this.onVis);
    window.addEventListener("blur", this.onVis);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.input.destroy();
    document.removeEventListener("visibilitychange", this.onVis);
    window.removeEventListener("blur", this.onVis);
  }

  private onVis = () => {
    if (document.hidden || !document.hasFocus()) this.pause();
  };

  // ------------------------------------------------------------ public API
  resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const touch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
    this.dpr = Math.min(window.devicePixelRatio || 1, touch ? 1.75 : 2);
    this.w = w;
    this.h = h;
    this.canvas.width = Math.round(w * this.dpr);
    this.canvas.height = Math.round(h * this.dpr);
    this.canvas.style.width = w + "px";
    this.canvas.style.height = h + "px";
    this.zoom = clamp(Math.min(w, h) / 560, 0.82, 1.55);
  }

  startGame() {
    this.resetRun();
    this.phase = "playing";
    sfx.start();
    this.startWave(1);
    this.hint = 9;
    this.hooks.onPhase("playing");
  }

  toMenu() {
    this.resetRun();
    this.phase = "menu";
    this.hooks.onPhase("menu");
  }

  pause() {
    if (this.phase === "playing" && !this.dead) {
      this.phase = "paused";
      this.input.reset();
      this.hooks.onPhase("paused");
    }
  }

  resume() {
    if (this.phase === "paused") {
      this.phase = "playing";
      this.last = performance.now();
      this.input.dashQueued = false;
      this.hooks.onPhase("playing");
    }
  }

  togglePause() {
    if (this.phase === "playing") this.pause();
    else if (this.phase === "paused") this.resume();
  }

  nextWave(wand: (string | null)[]) {
    this.wand = wand.slice();
    this.ptr = 0;
    this.refreshNext();
    this.phase = "playing";
    this.player.castT = 0.2;
    this.hooks.onPhase("playing");
    this.startWave(this.wave + 1);
  }

  isMuted() {
    return sfx.muted;
  }

  // ------------------------------------------------------------ setup
  private newPlayer() {
    return {
      x: W / 2, y: H / 2, vx: 0, vy: 0, hp: 100, maxHp: 100, mana: 120, maxMana: 120, aim: 0,
      dashT: 0, dashCd: 0, dashDx: 1, dashDy: 0, inv: 0, castT: 0, castCd: 0.2, kick: 0,
      lastMx: 0, lastMy: 1, dust: 0, hurtT: 0,
    };
  }

  private resetRun() {
    this.player = this.newPlayer();
    this.enemies.length = 0;
    this.projs.length = 0;
    this.ebul.length = 0;
    this.texts.length = 0;
    this.rings.length = 0;
    this.arcs.length = 0;
    this.fires.length = 0;
    this.orbs.length = 0;
    this.wand = [...START_WAND];
    this.wandCap = 5;
    this.ptr = 0;
    this.lastCast = { start: 0, end: 0, t: 0 };
    this.wave = 0;
    this.queue = [];
    this.clearing = false;
    this.vacuum = false;
    this.score = 0;
    this.shownScore = 0;
    this.kills = 0;
    this.combo = 0;
    this.comboT = 0;
    this.bestCombo = 0;
    this.runTime = 0;
    this.dead = false;
    this.deadT = 0;
    this.trauma = 0;
    this.hitstop = 0;
    this.timeScale = 1;
    this.hurtFlash = 0;
    this.whiteFlash = 0;
    this.hpLag = 100;
    this.banner.t = 0;
    this.hint = 0;
    this.input.dashQueued = false;
    this.refreshNext();
  }

  private refreshNext() {
    const sp = compact(this.wand);
    if (!sp.length) {
      this.nextColor = "#888";
      return;
    }
    this.nextColor = sp[this.ptr >= sp.length ? 0 : this.ptr].color;
  }

  private startWave(n: number) {
    this.wave = n;
    this.clearing = false;
    this.vacuum = false;
    this.queue = this.buildQueue(n);
    this.spawnT = n === 1 ? 0.15 : 0.7;
    this.banner = { text: `WAVE ${n}`, sub: n === 1 ? "Chain your spells. Survive." : "They keep coming...", t: 2.2, max: 2.2, color: "#ffd166" };
    if (n > 1) sfx.wave();
  }

  private buildQueue(n: number): EType[] {
    if (n === 1) return Array(7).fill("slime") as EType[];
    let budget = 4 + n * 3;
    const types = (Object.keys(ETYPES) as EType[]).filter((t) => ETYPES[t].minWave < n);
    const q: EType[] = [];
    while (budget > 0) {
      const pool = types.filter((t) => ETYPES[t].cost <= budget);
      const tot = pool.reduce((a, t) => a + ETYPES[t].w, 0);
      let r = Math.random() * tot;
      let pick: EType = "slime";
      for (const t of pool) {
        r -= ETYPES[t].w;
        if (r <= 0) { pick = t; break; }
      }
      q.push(pick);
      budget -= ETYPES[pick].cost;
    }
    return q;
  }

  // ------------------------------------------------------------ main loop
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const raw = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;
    this.frame(raw);
    this.render();
  };

  private frame(raw: number) {
    if (this.phase === "paused") return;
    let dt = raw;
    if (this.hitstop > 0) {
      this.hitstop -= raw;
      dt *= 0.06;
    }
    dt *= this.timeScale;
    this.time += dt;
    if (this.phase === "playing") {
      this.updateWorld(dt);
      if (this.dead) {
        this.deadT += raw;
        if (this.deadT > 1.7) {
          this.phase = "over";
          this.timeScale = 1;
          this.deadT = 0;
          this.hooks.onPhase("over");
          this.hooks.onOver({ score: this.score, wave: this.wave, kills: this.kills, bestCombo: this.bestCombo, time: this.runTime });
        }
      }
    } else if (this.phase === "over") {
      this.deadT += raw;
    } else {
      this.input.dashQueued = false;
      if (this.phase === "menu") {
        this.emberT -= dt;
        if (this.emberT <= 0) {
          this.emberT = 0.06;
          const c = ["#ffa033", "#7ff", "#d65bff"][Math.floor(Math.random() * 3)];
          this.emit(rand(RIM, W - RIM), rand(RIM, H - RIM), rand(-8, 8), rand(-30, -10), rand(1.5, 3), rand(2, 4), c, true, 0, 0, true);
        }
        this.player.aim += dt * 0.8;
      }
    }
    this.updateFx(dt);
    this.updateCamera(dt);
  }

  // ------------------------------------------------------------ world update
  private updateWorld(dt: number) {
    if (!this.dead) this.runTime += dt;
    this.updateWaves(dt);
    this.updatePlayer(dt);
    this.updateProjs(dt);
    this.updateEnemies(dt);
    this.updateEBullets(dt);
    this.updateFires(dt);
    this.updateOrbs(dt);
    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
    }
    if (this.hint > 0) this.hint -= dt;
  }

  private updateWaves(dt: number) {
    if (this.dead) return;
    if (this.clearing) {
      this.clearT -= dt;
      if (this.clearT <= 0) this.openAltar();
      return;
    }
    if (this.queue.length) {
      this.spawnT -= dt;
      const cap = 12 + this.wave * 2;
      if (this.spawnT <= 0 && this.enemies.length < cap) {
        this.spawnEnemy(this.queue.pop()!);
        this.spawnT = Math.max(0.16, 0.85 - this.wave * 0.05) * (this.wave === 1 ? 0.7 : 1);
      }
    } else if (this.enemies.length === 0) {
      this.clearing = true;
      this.clearT = 1.5;
      this.vacuum = true;
      const bonus = 50 * this.wave;
      this.score += bonus;
      this.scorePunch = 1;
      this.banner = { text: "WAVE CLEARED", sub: `+${bonus} bonus`, t: 1.6, max: 1.6, color: "#7dff9a" };
      sfx.wave();
      this.addRing(this.player.x, this.player.y, 10, 260, 0.7, "#7dff9a", 4, false);
      this.burst(this.player.x, this.player.y, 30, "#7dff9a", 260, 0.8, 4, true);
    }
  }

  private openAltar() {
    this.phase = "altar";
    this.projs.length = 0;
    this.ebul.length = 0;
    this.fires.length = 0;
    this.input.reset();
    const p = this.player;
    const before = p.hp;
    p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.3);
    p.mana = p.maxMana;
    const cap = Math.min(9, 5 + Math.floor(this.wave / 2));
    const newSlot = cap > this.wandCap;
    this.wandCap = cap;
    while (this.wand.length < cap) this.wand.push(null);
    sfx.pickup();
    this.hooks.onPhase("altar");
    this.hooks.onAltar({
      offers: pickOffers(this.wave),
      wave: this.wave,
      wand: this.wand.slice(),
      cap,
      newSlot,
      healed: Math.round(p.hp - before),
    });
  }

  private spawnPos(out: { x: number; y: number }) {
    const p = this.player;
    for (let i = 0; i < 24; i++) {
      const a = Math.random() * TAU;
      const d = 280 + Math.random() * 280;
      const x = p.x + Math.cos(a) * d;
      const y = p.y + Math.sin(a) * d;
      if (x < RIM + 40 || x > W - RIM - 40 || y < RIM + 40 || y > H - RIM - 40) continue;
      if (wallHit(x, y, 26)) continue;
      out.x = x;
      out.y = y;
      return;
    }
    out.x = rand(RIM + 80, W - RIM - 80);
    out.y = rand(RIM + 80, H - RIM - 80);
  }

  private tmpPos = { x: 0, y: 0 };

  private spawnEnemy(type: EType, at?: { x: number; y: number }, mini = false, instant = false) {
    const d = ETYPES[type];
    if (!at) {
      this.spawnPos(this.tmpPos);
      at = this.tmpPos;
    }
    const hpScale = 1 + 0.085 * (this.wave - 1);
    const hp = (mini ? d.hp * 0.7 : d.hp) * hpScale;
    const e: Enemy = {
      type, x: at.x, y: at.y, vx: 0, vy: 0, r: mini ? d.r * 0.85 : d.r, hp, maxHp: hp,
      speed: d.speed * (1 + Math.min(0.35, this.wave * 0.02)) * rand(0.92, 1.08), dmg: d.dmg, pts: mini ? Math.ceil(d.pts / 2) : d.pts,
      color: d.color, dark: d.dark, mass: d.mass,
      spawnT: instant ? 0 : 0.55, burn: 0, burnTick: 0, chill: 0, chillT: 0, frozen: 0, shock: 0,
      flash: 0, squash: 0, phase: Math.random() * TAU, shootT: rand(1, 2.2), dead: false, mini,
    };
    this.enemies.push(e);
    if (!instant) {
      this.addRing(e.x, e.y, 4, 30, 0.55, d.color, 2, false);
      sfx.spawn();
    }
  }

  // ------------------------------------------------------------ player
  private screenToWorld(sx: number, sy: number) {
    return { x: sx / this.zoom + this.camX, y: sy / this.zoom + this.camY };
  }

  private assist(a: number): number {
    const p = this.player;
    let best = a;
    let bd = 0.3;
    for (const e of this.enemies) {
      if (e.spawnT > 0) continue;
      const dx = e.x - p.x;
      const dy = e.y - p.y;
      const d = Math.hypot(dx, dy);
      if (d > 620) continue;
      const ang = Math.atan2(dy, dx);
      const diff = Math.abs(angDiff(a, ang)) - Math.atan2(e.r, d);
      if (diff < bd) {
        bd = diff;
        best = ang;
      }
    }
    return best;
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    const inp = this.input;
    if (this.dead) {
      p.vx *= 0.9;
      p.vy *= 0.9;
      inp.dashQueued = false;
      return;
    }
    p.inv = Math.max(0, p.inv - dt);
    p.hurtT = Math.max(0, p.hurtT - dt);
    p.kick = Math.max(0, p.kick - dt * 8);
    this.noMana = Math.max(0, this.noMana - dt);
    this.lastCast.t = Math.max(0, this.lastCast.t - dt);

    inp.moveVec(this.mv);
    let firing = false;
    if (inp.arrowAim(this.av)) {
      p.aim = Math.atan2(this.av.y, this.av.x);
      firing = true;
    } else if (inp.touchMode) {
      if (inp.aim.active) {
        const m = Math.hypot(inp.aim.x, inp.aim.y);
        if (m > 0.15) {
          p.aim = Math.atan2(inp.aim.y, inp.aim.x);
          if (m > 0.3) {
            firing = true;
            p.aim = this.assist(p.aim);
          }
        }
      } else if (inp.move.active === false && this.mv.x === 0 && this.mv.y === 0) {
        /* idle */
      }
    } else if (inp.mouse.seen) {
      const wp = this.screenToWorld(inp.mouse.x, inp.mouse.y);
      p.aim = Math.atan2(wp.y - p.y, wp.x - p.x);
      firing = inp.mouse.down;
    }

    // dash
    p.dashCd = Math.max(0, p.dashCd - dt);
    if (inp.dashQueued) {
      inp.dashQueued = false;
      if (p.dashCd <= 0 && p.dashT <= 0) {
        let dx = this.mv.x;
        let dy = this.mv.y;
        if (dx === 0 && dy === 0) {
          dx = p.lastMx || -Math.cos(p.aim);
          dy = p.lastMy || -Math.sin(p.aim);
        }
        const l = Math.hypot(dx, dy) || 1;
        p.dashDx = dx / l;
        p.dashDy = dy / l;
        p.dashT = 0.17;
        p.dashCd = 0.95;
        p.inv = Math.max(p.inv, 0.3);
        this.shake(0.12);
        sfx.dash();
        this.burst(p.x, p.y, 10, "#b9a0ff", 140, 0.4, 3, true);
      }
    }
    if (this.mv.x !== 0 || this.mv.y !== 0) {
      p.lastMx = this.mv.x;
      p.lastMy = this.mv.y;
    }
    if (p.dashT > 0) {
      p.dashT -= dt;
      p.vx = p.dashDx * 700;
      p.vy = p.dashDy * 700;
      this.emit(p.x, p.y, 0, 0, 0.3, 14, "#8a6cff", true, 0, 0, true);
      this.emit(p.x + rand(-4, 4), p.y + rand(-4, 4), rand(-30, 30), rand(-30, 30), 0.35, 4, "#fff", true, 2, 0, true);
    } else {
      const k = Math.min(1, dt * 16);
      p.vx += (this.mv.x * PSPEED - p.vx) * k;
      p.vy += (this.mv.y * PSPEED - p.vy) * k;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    for (let i = 0; i < 2; i++) {
      if (wallHit(p.x, p.y, PR)) {
        p.x = WH.px;
        p.y = WH.py;
        const dot = p.vx * WH.nx + p.vy * WH.ny;
        if (dot < 0) {
          p.vx -= dot * WH.nx;
          p.vy -= dot * WH.ny;
        }
      }
    }
    const spd = Math.hypot(p.vx, p.vy);
    p.dust -= dt;
    if (spd > 80 && p.dust <= 0 && p.dashT <= 0) {
      p.dust = 0.07;
      this.emit(p.x, p.y + 7, rand(-12, 12), rand(-12, 12), 0.4, rand(3, 5), "#4a4068", false, 2, 0, true);
    }

    p.mana = Math.min(p.maxMana, p.mana + 54 * dt);
    p.castT -= dt;
    if (firing && p.castT <= 0) this.cast();
  }

  private cast() {
    const p = this.player;
    const r = evalCast(this.wand, this.ptr);
    if (r.empty) {
      p.castT = 0.25;
      return;
    }
    const cost = Math.min(r.mana, p.maxMana * 0.96);
    if (p.mana < cost) {
      this.noMana = 0.35;
      p.castT = 0.07;
      sfx.empty();
      return;
    }
    p.mana -= cost;
    this.lastCast = { start: r.start, end: r.end, t: 0.35 };
    this.ptr = r.next;
    p.castCd = r.cooldown;
    p.castT = r.cooldown;
    this.refreshNext();

    const tipX = p.x + Math.cos(p.aim) * 24;
    const tipY = p.y + Math.sin(p.aim) * 24 + 2;
    const sounds = new Set<string>();
    let big = 0;
    for (const s of r.shots) {
      const ang = p.aim + s.offset + rand(-0.025, 0.025);
      this.spawnShot(s, tipX, tipY, ang, 0);
      sounds.add(s.spell.proj!.sound);
      big += s.spell.proj!.explode ? 0.12 : 0.02;
    }
    sounds.forEach((s) => sfx.cast(s));
    // juice
    p.kick = 1;
    const recoil = 14 + big * 60;
    p.vx -= Math.cos(p.aim) * recoil;
    p.vy -= Math.sin(p.aim) * recoil;
    this.shake(0.025 + Math.min(0.2, big));
    this.burst(tipX, tipY, 4 + r.shots.length * 2, this.nextColorOf(r.shots[0]), 150, 0.25, 3, true, 0.7, p.aim);
    this.emit(tipX, tipY, 0, 0, 0.12, 26, "#ffffff", true, 0, 0, true);
    if (r.wrapped && compact(this.wand).length > 1) {
      this.addRing(p.x, p.y, 8, 28, 0.25, "#fff", 2, false);
    }
  }

  private nextColorOf(s?: Shot) {
    return s ? s.spell.proj!.color : "#fff";
  }

  private spawnShot(shot: Shot, x: number, y: number, ang: number, gen: number) {
    if (this.projs.length > 320 || gen > 4) return;
    const pd = shot.spell.proj!;
    const m = shot.mods;
    const sp = pd.speed * m.speed;
    const a = ang + shot.offset * (gen > 0 ? 1 : 0);
    this.projs.push({
      x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, pd, m, dmg: pd.dmg + m.damage, life: pd.life,
      age: 0, bounces: (pd.bounce ?? 0) + m.bounce, pierce: m.pierce, hit: [], hitClear: 0,
      payload: shot.payload, ptype: shot.payloadType, ptimer: shot.timer ?? 0, pfired: false, gen,
      trailT: 0, homeT: 0, target: null, dead: false, tickT: 0, spin: Math.random() * TAU,
    });
  }

  private firePayload(q: Proj, exclude: Enemy | null, forward: boolean) {
    if (!q.payload || q.pfired) return;
    q.pfired = true;
    let ang = Math.random() * TAU;
    if (forward) ang = Math.atan2(q.vy, q.vx);
    else {
      let best = 380 * 380;
      for (const e of this.enemies) {
        if (e === exclude || e.dead || e.spawnT > 0) continue;
        const d = (e.x - q.x) ** 2 + (e.y - q.y) ** 2;
        if (d < best) {
          best = d;
          ang = Math.atan2(e.y - q.y, e.x - q.x);
        }
      }
    }
    for (const s of q.payload) this.spawnShot(s, q.x, q.y, ang, q.gen + 1);
    this.addRing(q.x, q.y, 4, 34, 0.3, "#3de0a0", 3, false);
    this.burst(q.x, q.y, 10, "#3de0a0", 170, 0.35, 3, true);
    this.shake(0.05);
    sfx.place();
  }

  // ------------------------------------------------------------ projectiles
  private updateProjs(dt: number) {
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const q = this.projs[i];
      const pd = q.pd;
      q.age += dt;
      q.life -= dt;
      if (q.hitClear > 0) {
        q.hitClear -= dt;
        if (q.hitClear <= 0) q.hit.length = 0;
      }

      // homing
      if (q.m.homing > 0) {
        q.homeT -= dt;
        if (q.homeT <= 0 || (q.target && q.target.dead)) {
          q.homeT = 0.12;
          q.target = null;
          let best = 460 * 460;
          for (const e of this.enemies) {
            if (e.dead || e.spawnT > 0 || q.hit.includes(e)) continue;
            const d = (e.x - q.x) ** 2 + (e.y - q.y) ** 2;
            if (d < best) { best = d; q.target = e; }
          }
        }
        if (q.target) {
          const sp = Math.hypot(q.vx, q.vy);
          const cur = Math.atan2(q.vy, q.vx);
          const want = Math.atan2(q.target.y - q.y, q.target.x - q.x);
          const turn = clamp(angDiff(cur, want), -6 * dt, 6 * dt);
          q.vx = Math.cos(cur + turn) * sp;
          q.vy = Math.sin(cur + turn) * sp;
        }
      }
      if (pd.drag) {
        const f = Math.exp(-pd.drag * dt);
        q.vx *= f;
        q.vy *= f;
      }

      // black hole
      if (pd.blackhole) {
        q.tickT -= dt;
        const R = 175;
        for (const e of this.enemies) {
          if (e.dead || e.spawnT > 0) continue;
          const dx = q.x - e.x;
          const dy = q.y - e.y;
          const d = Math.hypot(dx, dy);
          if (d < R && d > 4) {
            const pull = (70 + 260 * (1 - d / R)) / Math.sqrt(e.mass);
            e.x += (dx / d) * pull * dt;
            e.y += (dy / d) * pull * dt;
          }
        }
        for (const b of this.ebul) {
          const dx = q.x - b.x;
          const dy = q.y - b.y;
          if (dx * dx + dy * dy < R * R) { b.vx += dx * dt * 2; b.vy += dy * dt * 2; }
        }
        if (q.tickT <= 0) {
          q.tickT = 0.25;
          for (const e of this.enemies) {
            if (e.dead || e.spawnT > 0) continue;
            if ((e.x - q.x) ** 2 + (e.y - q.y) ** 2 < 60 * 60) this.hurtEnemy(e, 4, { quiet: true, noReact: true });
          }
        }
        // swirl particles
        if (Math.random() < 0.9) {
          const a = Math.random() * TAU;
          const rr = rand(40, 90);
          this.emit(q.x + Math.cos(a) * rr, q.y + Math.sin(a) * rr, -Math.cos(a) * rr * 2.2 - Math.sin(a) * 70, -Math.sin(a) * rr * 2.2 + Math.cos(a) * 70, 0.45, 3, Math.random() < 0.5 ? "#b88cff" : "#6a3cff", true, 0, 0, true);
        }
        this.shake(0.012);
      }

      // wavy
      if (q.m.wavy > 0) {
        const sp = Math.hypot(q.vx, q.vy) || 1;
        const k = Math.cos(q.age * 13) * 170 * dt;
        q.x += (-q.vy / sp) * k;
        q.y += (q.vx / sp) * k;
      }

      // timer payload
      if (q.payload && q.ptype === "timer" && !q.pfired) {
        q.ptimer -= dt;
        if (q.ptimer <= 0) this.firePayload(q, null, true);
      }

      // move in substeps
      const speed = Math.hypot(q.vx, q.vy);
      const steps = clamp(Math.ceil((speed * dt) / (pd.radius + 5)), 1, 7);
      const sdt = dt / steps;
      for (let s = 0; s < steps && !q.dead; s++) {
        q.x += q.vx * sdt;
        q.y += q.vy * sdt;
        if (wallHit(q.x, q.y, pd.radius * 0.7)) {
          if (q.bounces > 0) {
            const dot = q.vx * WH.nx + q.vy * WH.ny;
            q.vx -= 2 * dot * WH.nx;
            q.vy -= 2 * dot * WH.ny;
            q.x = WH.px;
            q.y = WH.py;
            q.bounces--;
            if (!pd.blackhole) {
              this.burst(q.x, q.y, 4, pd.color, 110, 0.25, 3, true);
              if (speed > 200) this.shake(0.02);
            }
          } else {
            this.endProj(q, null);
          }
          continue;
        }
        if (!pd.noHit) {
          for (let k = 0; k < this.enemies.length; k++) {
            const e = this.enemies[k];
            if (e.dead || e.spawnT > 0) continue;
            const dx = e.x - q.x;
            const dy = e.y - q.y;
            const rr = e.r + pd.radius;
            if (dx * dx + dy * dy < rr * rr) {
              if (q.hit.includes(e)) continue;
              this.projHit(q, e, dx, dy);
              if (q.dead) break;
            }
          }
        }
      }
      if (!q.dead) {
        // visual trail / emitters
        q.trailT -= dt;
        if (q.trailT <= 0) {
          q.trailT = pd.shape === "bolt" ? 0.025 : 0.03;
          if (!pd.blackhole) this.emit(q.x, q.y, rand(-12, 12), rand(-12, 12), 0.28, pd.radius * 0.9, pd.color, true, 3, 0, true);
          if (q.m.trail > 0) {
            if (this.fires.length < 140) this.fires.push({ x: q.x, y: q.y, life: 1.6, tick: 0 });
          }
        }
        if (q.life <= 0) this.endProj(q, null);
      }
      if (q.dead) {
        this.projs[i] = this.projs[this.projs.length - 1];
        this.projs.pop();
      }
    }
  }

  private projHit(q: Proj, e: Enemy, dx: number, dy: number) {
    const pd = q.pd;
    const d = Math.hypot(dx, dy) || 1;
    const sp = Math.hypot(q.vx, q.vy) || 1;
    this.hurtEnemy(e, q.dmg, {
      fx: pd.fx, heavy: q.m.damage >= 6, kx: q.vx / sp, ky: q.vy / sp, kb: 120 + q.m.damage * 14,
    });
    this.burst(q.x, q.y, 5, pd.color, 150, 0.3, 3, true);
    this.emit(q.x, q.y, 0, 0, 0.1, 22, "#fff", true, 0, 0, true);
    this.shake(0.03);
    if (pd.chain) this.chainLightning(q, e);
    if (q.pierce > 0) {
      q.pierce--;
      q.hit.push(e);
      q.hitClear = 0.3;
      return;
    }
    if (q.bounces > 0) {
      const nx = -dx / d;
      const ny = -dy / d;
      const dot = q.vx * nx + q.vy * ny;
      q.vx -= 2 * dot * nx;
      q.vy -= 2 * dot * ny;
      q.x = e.x + nx * (e.r + pd.radius + 1);
      q.y = e.y + ny * (e.r + pd.radius + 1);
      q.bounces--;
      q.hit.push(e);
      q.hitClear = 0.15;
      return;
    }
    this.endProj(q, e);
  }

  private chainLightning(q: Proj, from: Enemy) {
    const pts = [q.x, q.y];
    let cur: { x: number; y: number } = from;
    const used: Enemy[] = [from];
    for (let n = 0; n < (q.pd.chain || 0); n++) {
      let best: Enemy | null = null;
      let bd = 170 * 170;
      for (const e of this.enemies) {
        if (e.dead || e.spawnT > 0 || used.includes(e)) continue;
        const d = (e.x - cur.x) ** 2 + (e.y - cur.y) ** 2;
        if (d < bd) { bd = d; best = e; }
      }
      if (!best) break;
      used.push(best);
      pts.push(cur.x, cur.y, best.x, best.y);
      this.hurtEnemy(best, q.dmg * 0.65, { fx: "shock", quiet: false });
      this.burst(best.x, best.y, 4, "#ffee55", 130, 0.3, 3, true);
      cur = best;
    }
    this.arcs.push({ pts, life: 0.18, color: "#ffee55" });
    if (pts.length > 2) this.arcs.push({ pts, life: 0.1, color: "#ffffff" });
  }

  private endProj(q: Proj, hitEnemy: Enemy | null) {
    if (q.dead) return;
    q.dead = true;
    const pd = q.pd;
    if (pd.explode) {
      this.explode(q.x, q.y, pd.explode.r, pd.explode.dmg + q.m.damage * 0.6, pd.fx, pd.color, false);
    } else {
      this.burst(q.x, q.y, 6, pd.color, 130, 0.3, 3, true);
    }
    if (q.payload && !q.pfired) this.firePayload(q, hitEnemy, q.ptype === "timer");
  }

  // ------------------------------------------------------------ damage / reactions
  private hurtEnemy(e: Enemy, dmgIn: number, o: HurtOpts) {
    if (e.dead || e.spawnT > 0) return;
    let dmg = dmgIn;
    const fx = o.fx || "none";
    let popColor = "#ffffff";
    if (e.frozen > 0 && (o.explosion || o.heavy) && dmg >= 3 && !o.noReact) {
      dmg *= 2.3;
      e.frozen = 0;
      this.reaction(e.x, e.y - 12, "SHATTER!", "#aef0ff", 30);
      this.burst(e.x, e.y, 18, "#cdf4ff", 280, 0.6, 4, true, TAU);
      this.burst(e.x, e.y, 8, "#ffffff", 200, 0.5, 3, false, TAU);
      sfx.shatter();
      this.shake(0.28);
      this.hitstop = Math.max(this.hitstop, 0.05);
    }
    if (fx === "fire") {
      popColor = "#ffb066";
      if (e.frozen > 0 && !o.noReact) {
        e.frozen = 0;
        this.steam(e.x, e.y);
      }
      e.chill = 0;
      if (e.burn <= 0) this.burst(e.x, e.y, 6, "#ff9a2e", 120, 0.4, 3, true);
      e.burn = 3.2;
    } else if (fx === "frost") {
      popColor = "#9fdcff";
      if (e.burn > 0) {
        e.burn = 0;
        this.burst(e.x, e.y, 6, "#cfd8e8", 70, 0.5, 4, false);
      } else if (e.frozen <= 0) {
        e.chill++;
        e.chillT = 3;
        if (e.chill >= 3) {
          e.chill = 0;
          e.frozen = 2.6;
          e.flash = 0.12;
          this.burst(e.x, e.y, 12, "#bfe9ff", 160, 0.5, 4, true, TAU);
          this.addText(e.x, e.y - e.r - 14, "FROZEN", "#9fdcff", 18);
          sfx.freeze();
        }
      }
    } else if (fx === "shock") {
      popColor = "#fff27a";
      e.shock = 1.4;
      if (e.burn > 0 && !o.noReact) {
        e.burn = 0;
        this.reaction(e.x, e.y - 12, "OVERLOAD!", "#ffee55", 30);
        this.explode(e.x, e.y, 70, 16, "shock", "#ffee55", true);
      }
    }
    e.hp -= dmg;
    e.flash = 0.09;
    e.squash = 1;
    if (o.kx !== undefined && o.ky !== undefined) {
      const kb = (o.kb ?? 140) / e.mass;
      e.vx += o.kx * kb;
      e.vy += o.ky * kb;
    }
    if (!o.quiet && dmg >= 1.5) this.addText(e.x + rand(-6, 6), e.y - e.r, String(Math.round(dmg)), popColor, dmg >= 12 ? 26 : 18);
    if (!o.quiet) sfx.hit();
    if (e.hp <= 0) this.killEnemy(e);
  }

  private steam(x: number, y: number) {
    this.reaction(x, y - 14, "STEAM!", "#e8f0ff", 20);
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if ((e.x - x) ** 2 + (e.y - y) ** 2 < 64 * 64) this.hurtEnemy(e, 9, { noReact: true, quiet: true });
    }
    for (let i = 0; i < 18; i++) {
      const a = Math.random() * TAU;
      const s = rand(20, 110);
      this.emit(x, y, Math.cos(a) * s, Math.sin(a) * s - 20, rand(0.5, 1), rand(6, 12), Math.random() < 0.5 ? "#c9d4ea" : "#8d9ab5", false, 2, -20, false);
    }
    this.addRing(x, y, 6, 64, 0.35, "#ffffff", 3, false);
  }

  private reaction(x: number, y: number, text: string, color: string, bonus: number) {
    const gain = Math.round(bonus * this.mult());
    this.score += gain;
    this.scorePunch = 1;
    this.addText(x, y - 10, text, color, 30, 1.1);
    this.addText(x, y + 12, `+${gain}`, "#ffd166", 20, 0.9);
    this.addRing(x, y, 8, 52, 0.4, color, 3, false);
    this.whiteFlash = Math.max(this.whiteFlash, 0.15);
    sfx.react();
  }

  private mult() {
    return 1 + Math.min(this.combo, 40) * 0.1;
  }

  private explode(x: number, y: number, r: number, dmg: number, fx: Fx, color: string, noReact: boolean) {
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const dx = e.x - x;
      const dy = e.y - y;
      const d = Math.hypot(dx, dy);
      if (d < r + e.r) {
        const f = 1 - 0.5 * Math.min(1, d / (r + e.r));
        this.hurtEnemy(e, dmg * f, { fx, explosion: true, noReact, kx: dx / (d || 1), ky: dy / (d || 1), kb: 340 * f });
      }
    }
    for (let i = this.ebul.length - 1; i >= 0; i--) {
      const b = this.ebul[i];
      if ((b.x - x) ** 2 + (b.y - y) ** 2 < r * r) {
        this.burst(b.x, b.y, 4, "#ff5d9e", 100, 0.3, 3, true);
        this.ebul.splice(i, 1);
      }
    }
    const s = r / 100;
    this.shake(0.22 + s * 0.45);
    this.hitstop = Math.max(this.hitstop, 0.02 + 0.03 * s);
    this.whiteFlash = Math.max(this.whiteFlash, 0.1 + s * 0.12);
    this.addRing(x, y, 6, r * 1.15, 0.38, color, 5, false);
    this.rings.push({ x, y, r0: r * 0.3, r1: r * 1.5, life: 0.3, max: 0.3, color, width: 0, flash: true });
    const n = Math.round(14 + r * 0.35);
    this.burst(x, y, n, color, 120 + r * 3, 0.55, 4, true, TAU);
    this.burst(x, y, Math.round(n / 2), "#ffffff", 100 + r * 2, 0.35, 3, true, TAU);
    for (let i = 0; i < n / 3; i++) {
      const a = Math.random() * TAU;
      const sp = rand(20, 100 + r);
      this.emit(x, y, Math.cos(a) * sp, Math.sin(a) * sp, rand(0.5, 1.1), rand(5, 10), "#2a2336", false, 2.5, -10, false);
    }
    if (fx === "fire") {
      for (let i = 0; i < 5; i++) {
        if (this.fires.length < 140) this.fires.push({ x: x + rand(-r * 0.5, r * 0.5), y: y + rand(-r * 0.5, r * 0.5), life: rand(1, 1.8), tick: 0 });
      }
    }
    sfx.boom(Math.min(1, s));
  }

  private killEnemy(e: Enemy) {
    if (e.dead) return;
    e.dead = true;
    this.kills++;
    this.combo++;
    this.comboT = 3.2;
    if (this.combo > this.bestCombo) this.bestCombo = this.combo;
    const gain = Math.round(e.pts * this.mult());
    this.score += gain;
    this.scorePunch = 1;
    const frozen = e.frozen > 0;
    this.addText(e.x, e.y - e.r - 4, `+${gain}`, "#ffd166", e.r > 16 ? 26 : 20);
    const col = frozen ? "#bfe9ff" : e.color;
    this.burst(e.x, e.y, 10 + Math.round(e.r), col, 200, 0.6, 4, true, TAU);
    this.burst(e.x, e.y, 6, e.dark, 150, 0.7, 5, false, TAU);
    this.addRing(e.x, e.y, 4, e.r * 2.8, 0.3, col, 3, false);
    const big = e.r > 18;
    this.shake(big ? 0.38 : 0.09);
    this.hitstop = Math.max(this.hitstop, big ? 0.07 : 0.014);
    sfx.kill(this.combo);
    if (e.type === "jelly") {
      for (let i = 0; i < 2; i++) {
        const a = Math.random() * TAU;
        const pos = { x: e.x + Math.cos(a) * 10, y: e.y + Math.sin(a) * 10 };
        this.spawnEnemy("slime", pos, true, true);
        const ne = this.enemies[this.enemies.length - 1];
        ne.vx = Math.cos(a) * 220;
        ne.vy = Math.sin(a) * 220;
        ne.color = "#7fe8f5";
      }
    }
    if (Math.random() < (e.type === "spitter" ? 0.18 : e.type === "brute" ? 0.4 : 0.06)) {
      this.orbs.push({ x: e.x, y: e.y, vx: rand(-60, 60), vy: rand(-60, 60), life: 12 });
    }
  }

  private hurtPlayer(dmg: number, fx: number, fy: number) {
    const p = this.player;
    if (p.inv > 0 || this.dead) return;
    p.hp -= dmg;
    p.inv = 0.9;
    p.hurtT = 0.4;
    this.hurtFlash = 1;
    this.combo = 0;
    this.comboT = 0;
    this.shake(0.6);
    this.hitstop = Math.max(this.hitstop, 0.07);
    sfx.hurt();
    const a = Math.atan2(p.y - fy, p.x - fx);
    p.vx += Math.cos(a) * 320;
    p.vy += Math.sin(a) * 320;
    this.burst(p.x, p.y, 14, "#ff4d6d", 220, 0.5, 4, true, TAU);
    this.addText(p.x, p.y - 20, `-${Math.round(dmg)}`, "#ff6b86", 26);
    if (p.hp <= 0) {
      p.hp = 0;
      this.die();
    }
  }

  private die() {
    this.dead = true;
    this.deadT = 0;
    this.timeScale = 0.3;
    const p = this.player;
    this.shake(1);
    sfx.over();
    this.burst(p.x, p.y, 50, "#b58cff", 380, 1.1, 5, true, TAU);
    this.burst(p.x, p.y, 24, "#ffffff", 260, 0.8, 4, true, TAU);
    this.addRing(p.x, p.y, 10, 300, 0.9, "#b58cff", 6, false);
    this.rings.push({ x: p.x, y: p.y, r0: 20, r1: 260, life: 0.6, max: 0.6, color: "#ffffff", width: 0, flash: true });
    this.whiteFlash = 0.5;
    this.projs.length = 0;
    this.ebul.length = 0;
  }

  // ------------------------------------------------------------ enemies etc
  private updateEnemies(dt: number) {
    const p = this.player;
    const list = this.enemies;
    for (let i = 0; i < list.length; i++) {
      const e = list[i];
      if (e.dead) {
        list[i] = list[list.length - 1];
        list.pop();
        i--;
        continue;
      }
      e.flash -= dt;
      e.squash = Math.max(0, e.squash - dt * 6);
      if (e.spawnT > 0) {
        e.spawnT -= dt;
        if (Math.random() < 0.5) this.emit(e.x + rand(-14, 14), e.y + rand(-14, 14), 0, -30, 0.4, 3, e.color, true, 0, 0, true);
        continue;
      }
      let sm = 1;
      if (e.frozen > 0) {
        e.frozen -= dt;
        sm = 0;
        if (e.frozen <= 0) this.burst(e.x, e.y, 8, "#bfe9ff", 120, 0.4, 3, true, TAU);
      } else if (e.chill > 0) {
        sm = 1 - 0.18 * e.chill;
        e.chillT -= dt;
        if (e.chillT <= 0) e.chill = 0;
      }
      if (e.shock > 0) {
        e.shock -= dt;
        sm *= 0.75;
        if (Math.random() < 0.3) this.emit(e.x + rand(-e.r, e.r), e.y + rand(-e.r, e.r), rand(-60, 60), rand(-60, 60), 0.18, 3, "#fff27a", true, 0, 0, true);
      }
      if (e.burn > 0) {
        e.burn -= dt;
        e.burnTick -= dt;
        if (e.burnTick <= 0) {
          e.burnTick = 0.42;
          this.hurtEnemy(e, 2.2, { quiet: true, noReact: true });
          if (e.dead) continue;
        }
        if (Math.random() < 0.6) this.emit(e.x + rand(-e.r * 0.6, e.r * 0.6), e.y + rand(-2, e.r * 0.4), rand(-10, 10), rand(-70, -30), rand(0.3, 0.6), rand(3, 6), Math.random() < 0.5 ? "#ff8a2a" : "#ffd24d", true, 0, 0, true);
      }

      const dx = p.x - e.x;
      const dy = p.y - e.y;
      const dist = Math.hypot(dx, dy) || 1;
      let tx = dx / dist;
      let ty = dy / dist;
      let spd = e.speed * sm;
      const t = this.time;
      if (e.type === "bat") {
        const w = Math.sin(t * 4.5 + e.phase) * 1.0;
        const c = Math.cos(w);
        const s = Math.sin(w);
        const nx = tx * c - ty * s;
        ty = tx * s + ty * c;
        tx = nx;
        spd *= 1 + Math.sin(t * 7 + e.phase) * 0.3;
      } else if (e.type === "spitter") {
        if (dist < 190) { tx = -tx; ty = -ty; }
        else if (dist < 270) { const nx = -ty; ty = tx; tx = nx; spd *= 0.6; }
        if (e.frozen <= 0) {
          e.shootT -= dt;
          if (e.shootT <= 0 && dist < 560 && !this.dead) {
            e.shootT = Math.max(1.3, 2.4 - this.wave * 0.04);
            this.ebul.push({ x: e.x, y: e.y, vx: (dx / dist) * 200, vy: (dy / dist) * 200, life: 4, dmg: 10 });
            this.burst(e.x, e.y, 5, "#ff5d9e", 100, 0.25, 3, true);
            e.squash = 0.8;
          }
        }
      } else if (e.type === "slime" || e.type === "jelly") {
        spd *= 0.75 + 0.5 * Math.max(0, Math.sin(t * 5 + e.phase));
      }
      if (this.dead) spd = 0;
      const k = Math.min(1, dt * (e.type === "bat" ? 6 : 4.5));
      e.vx += (tx * spd - e.vx) * k;
      e.vy += (ty * spd - e.vy) * k;
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      if (wallHit(e.x, e.y, e.r)) {
        e.x = WH.px;
        e.y = WH.py;
        const dot = e.vx * WH.nx + e.vy * WH.ny;
        if (dot < 0) { e.vx -= dot * WH.nx; e.vy -= dot * WH.ny; }
      }
      // separation
      for (let j = i + 1; j < list.length; j++) {
        const o = list[j];
        if (o.dead || o.spawnT > 0) continue;
        const ox = o.x - e.x;
        const oy = o.y - e.y;
        const rr = (e.r + o.r) * 0.85;
        const d2 = ox * ox + oy * oy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2);
          const push = (rr - d) * 0.5;
          const nx = ox / d;
          const ny = oy / d;
          const wa = o.mass / (e.mass + o.mass);
          e.x -= nx * push * wa * 2;
          e.y -= ny * push * wa * 2;
          o.x += nx * push * (1 - wa) * 2;
          o.y += ny * push * (1 - wa) * 2;
        }
      }
      // contact
      if (!this.dead && dist < e.r + PR - 1 && e.frozen <= 0) {
        if (p.inv <= 0) {
          this.hurtPlayer(e.dmg, e.x, e.y);
          e.vx -= tx * 240;
          e.vy -= ty * 240;
          e.squash = 1;
        }
      }
    }
  }

  private updateEBullets(dt: number) {
    const p = this.player;
    for (let i = this.ebul.length - 1; i >= 0; i--) {
      const b = this.ebul[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      const kill = b.life <= 0 || wallHit(b.x, b.y, 4) || (!this.dead && p.inv <= 0 && (b.x - p.x) ** 2 + (b.y - p.y) ** 2 < (PR + 5) ** 2);
      if (kill && !this.dead && p.inv <= 0 && (b.x - p.x) ** 2 + (b.y - p.y) ** 2 < (PR + 6) ** 2) {
        this.hurtPlayer(b.dmg, b.x - b.vx, b.y - b.vy);
      }
      if (Math.random() < 0.5) this.emit(b.x, b.y, 0, 0, 0.25, 4, "#ff5d9e", true, 0, 0, true);
      if (kill) {
        this.burst(b.x, b.y, 4, "#ff5d9e", 90, 0.3, 3, true);
        this.ebul[i] = this.ebul[this.ebul.length - 1];
        this.ebul.pop();
      }
    }
  }

  private updateFires(dt: number) {
    for (let i = this.fires.length - 1; i >= 0; i--) {
      const f = this.fires[i];
      f.life -= dt;
      f.tick -= dt;
      if (Math.random() < 0.25) this.emit(f.x + rand(-6, 6), f.y + rand(-4, 4), rand(-8, 8), rand(-60, -25), rand(0.25, 0.5), rand(3, 6), Math.random() < 0.5 ? "#ff8a2a" : "#ffd24d", true, 0, 0, true);
      if (f.tick <= 0) {
        f.tick = 0.3;
        for (const e of this.enemies) {
          if (e.dead || e.spawnT > 0) continue;
          const rr = e.r + 14;
          if ((e.x - f.x) ** 2 + (e.y - f.y) ** 2 < rr * rr) this.hurtEnemy(e, 1.5, { fx: "fire", quiet: true });
        }
      }
      if (f.life <= 0) {
        this.fires[i] = this.fires[this.fires.length - 1];
        this.fires.pop();
      }
    }
  }

  private updateOrbs(dt: number) {
    const p = this.player;
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      o.life -= dt;
      const dx = p.x - o.x;
      const dy = p.y - o.y;
      const d = Math.hypot(dx, dy) || 1;
      if (d < 110 || this.vacuum) {
        const pull = this.vacuum ? 700 : 420;
        o.vx += (dx / d) * pull * dt;
        o.vy += (dy / d) * pull * dt;
      }
      o.vx *= 1 - 3 * dt;
      o.vy *= 1 - 3 * dt;
      o.x += o.vx * dt;
      o.y += o.vy * dt;
      if (!this.dead && d < 17) {
        const heal = 10;
        p.hp = Math.min(p.maxHp, p.hp + heal);
        this.addText(p.x, p.y - 22, `+${heal} HP`, "#7dff9a", 20);
        this.burst(p.x, p.y, 10, "#7dff9a", 140, 0.4, 3, true, TAU);
        sfx.pickup();
        o.life = 0;
      }
      if (o.life <= 0) {
        this.orbs[i] = this.orbs[this.orbs.length - 1];
        this.orbs.pop();
      }
    }
  }

  // ------------------------------------------------------------ fx
  shake(a: number) {
    this.trauma = Math.min(1, this.trauma + a);
  }

  private emit(x: number, y: number, vx: number, vy: number, life: number, size: number, color: string, add: boolean, drag: number, grav: number, shrink: boolean) {
    if (this.parts.length > 850) return;
    const p = this.pool.pop() || ({} as Particle);
    p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life; p.size = size; p.color = color;
    p.add = add; p.drag = drag; p.grav = grav; p.shrink = shrink;
    this.parts.push(p);
  }

  private burst(x: number, y: number, n: number, color: string, speed: number, life: number, size: number, add: boolean, spread = TAU, ang = 0) {
    for (let i = 0; i < n; i++) {
      const a = spread >= TAU ? Math.random() * TAU : ang + (Math.random() - 0.5) * spread;
      const s = speed * rand(0.25, 1);
      this.emit(x, y, Math.cos(a) * s, Math.sin(a) * s, life * rand(0.5, 1), size * rand(0.6, 1.2), color, add, 3, 0, true);
    }
  }

  private addRing(x: number, y: number, r0: number, r1: number, life: number, color: string, width: number, flash: boolean) {
    if (this.rings.length > 60) this.rings.shift();
    this.rings.push({ x, y, r0, r1, life, max: life, color, width, flash });
  }

  private addText(x: number, y: number, text: string, color: string, size: number, life = 0.8) {
    if (this.texts.length > 36) this.texts.shift();
    this.texts.push({ x, y, vy: -46, text, color, size, life, max: life });
  }

  private updateFx(dt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.pool.push(p);
        this.parts[i] = this.parts[this.parts.length - 1];
        this.parts.pop();
        continue;
      }
      if (p.drag) {
        const f = Math.max(0, 1 - p.drag * dt);
        p.vx *= f;
        p.vy *= f;
      }
      p.vy += p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y += t.vy * dt;
      t.vy *= 1 - 2.2 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      this.rings[i].life -= dt;
      if (this.rings[i].life <= 0) this.rings.splice(i, 1);
    }
    for (let i = this.arcs.length - 1; i >= 0; i--) {
      this.arcs[i].life -= dt;
      if (this.arcs[i].life <= 0) this.arcs.splice(i, 1);
    }
    this.trauma = Math.max(0, this.trauma - dt * 1.7);
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 2.2);
    this.whiteFlash = Math.max(0, this.whiteFlash - dt * 1.6);
    this.scorePunch = Math.max(0, this.scorePunch - dt * 5);
    this.shownScore += (this.score - this.shownScore) * Math.min(1, dt * 10);
    if (Math.abs(this.score - this.shownScore) < 1) this.shownScore = this.score;
    this.hpLag += (this.player.hp - this.hpLag) * Math.min(1, dt * 2.5);
    if (this.banner.t > 0) this.banner.t -= dt;
  }

  private updateCamera(dt: number) {
    const p = this.player;
    const vw = this.w / this.zoom;
    const vh = this.h / this.zoom;
    const look = this.phase === "playing" && !this.dead ? 50 : 0;
    const tx = p.x + Math.cos(p.aim) * look;
    const ty = p.y + Math.sin(p.aim) * look;
    let cx = tx - vw / 2;
    let cy = ty - vh / 2;
    cx = vw >= W ? (W - vw) / 2 : clamp(cx, 0, W - vw);
    cy = vh >= H ? (H - vh) / 2 : clamp(cy, 0, H - vh);
    if (this.phase === "menu") {
      cx = vw >= W ? (W - vw) / 2 : (W - vw) / 2;
      cy = vh >= H ? (H - vh) / 2 : (H - vh) / 2;
    }
    const k = this.camInit ? Math.min(1, dt * 7) : 1;
    this.camInit = true;
    this.camX += (cx - this.camX) * k;
    this.camY += (cy - this.camY) * k;
  }
  private camInit = false;

  // ------------------------------------------------------------ render
  private render() {
    const ctx = this.ctx;
    const dpr = this.dpr;
    const z = this.zoom * dpr;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#07050d";
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    const tr = this.trauma * this.trauma;
    const sx = (Math.random() - 0.5) * 2 * 20 * tr;
    const sy = (Math.random() - 0.5) * 2 * 20 * tr;
    ctx.setTransform(z, 0, 0, z, (-this.camX * this.zoom + sx) * dpr, (-this.camY * this.zoom + sy) * dpr);
    ctx.drawImage(this.bg, 0, 0);

    this.drawFires();
    this.drawOrbs();
    this.drawEnemies();
    if (!this.dead) this.drawPlayer();
    this.drawEBullets();
    this.drawProjs();
    this.drawParticles();
    this.drawArcs();
    this.drawRings();
    this.drawTexts();

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // screen flashes
    if (this.hurtFlash > 0) {
      const g = ctx.createRadialGradient(this.w / 2, this.h / 2, Math.min(this.w, this.h) * 0.25, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.7);
      g.addColorStop(0, "rgba(255,30,70,0)");
      g.addColorStop(1, `rgba(255,30,70,${(this.hurtFlash * 0.55).toFixed(3)})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, this.w, this.h);
    }
    if (this.whiteFlash > 0.01) {
      ctx.fillStyle = `rgba(255,255,255,${(this.whiteFlash * 0.35).toFixed(3)})`;
      ctx.fillRect(0, 0, this.w, this.h);
    }
    if (this.phase !== "menu") {
      this.drawHud();
      if (this.input.touchMode && this.phase === "playing") this.drawTouch();
    }
  }

  private drawFires() {
    const ctx = this.ctx;
    ctx.globalCompositeOperation = "lighter";
    const g = glowSprite("#ff8a2a");
    for (const f of this.fires) {
      const a = Math.min(1, f.life) * (0.65 + Math.random() * 0.25);
      ctx.globalAlpha = a;
      ctx.drawImage(g, f.x - 22, f.y - 22, 44, 44);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private drawOrbs() {
    const ctx = this.ctx;
    for (const o of this.orbs) {
      if (o.life < 3 && Math.floor(this.time * 10) % 2 === 0) continue;
      const bob = Math.sin(this.time * 6 + o.x) * 2;
      ctx.globalCompositeOperation = "lighter";
      ctx.drawImage(glowSprite("#7dff9a"), o.x - 20, o.y - 20 + bob, 40, 40);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "#7dff9a";
      ctx.beginPath();
      ctx.arc(o.x, o.y + bob, 5, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.fillRect(o.x - 1, o.y + bob - 3, 2, 6);
      ctx.fillRect(o.x - 3, o.y + bob - 1, 6, 2);
    }
  }

  private drawEnemies() {
    const ctx = this.ctx;
    const p = this.player;
    for (const e of this.enemies) {
      ctx.save();
      ctx.translate(e.x, e.y);
      if (e.spawnT > 0) {
        const k = 1 - e.spawnT / 0.55;
        ctx.globalAlpha = 0.35 + k * 0.4;
        ctx.strokeStyle = e.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 4, e.r * (1.6 - k * 0.6), e.r * (1.6 - k * 0.6) * 0.6, 0, 0, TAU);
        ctx.stroke();
        ctx.scale(k, k);
      }
      const r = e.r;
      // shadow
      ctx.fillStyle = "rgba(0,0,0,.35)";
      ctx.beginPath();
      ctx.ellipse(0, r * 0.75, r * 0.95, r * 0.4, 0, 0, TAU);
      ctx.fill();

      const bob = Math.sin(this.time * 8 + e.phase);
      const sq = e.squash;
      const sxs = 1 + sq * 0.28 + bob * 0.04;
      const sys = 1 - sq * 0.24 - bob * 0.04;
      ctx.scale(sxs, sys);
      if (e.type === "bat") ctx.translate(0, Math.sin(this.time * 12 + e.phase) * 2 - 4);

      const frozen = e.frozen > 0;
      const body = e.flash > 0 ? "#ffffff" : frozen ? "#bfe9ff" : e.color;
      const dark = e.flash > 0 ? "#e8e8e8" : frozen ? "#7fb6e0" : e.dark;

      if (e.type === "bat") {
        const flap = Math.sin(this.time * 24 + e.phase) * 0.6;
        ctx.fillStyle = dark;
        for (const s of [-1, 1]) {
          ctx.beginPath();
          ctx.moveTo(s * 4, -2);
          ctx.lineTo(s * (r + 9), -8 - flap * 10);
          ctx.lineTo(s * (r + 4), 3);
          ctx.lineTo(s * (r + 8), 7 + flap * 4);
          ctx.lineTo(s * 4, 5);
          ctx.closePath();
          ctx.fill();
        }
      }
      if (e.type === "brute") {
        ctx.fillStyle = e.flash > 0 ? "#fff" : "#f0e6d0";
        for (const s of [-1, 1]) {
          ctx.beginPath();
          ctx.moveTo(s * r * 0.5, -r * 0.7);
          ctx.lineTo(s * r * 0.95, -r * 1.3);
          ctx.lineTo(s * r * 0.8, -r * 0.45);
          ctx.fill();
        }
      }
      // body
      ctx.fillStyle = dark;
      ctx.beginPath();
      ctx.ellipse(0, 2, r, r * 0.92, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.ellipse(0, -1, r * 0.95, r * 0.85, 0, 0, TAU);
      ctx.fill();
      // highlight
      ctx.fillStyle = "rgba(255,255,255,.28)";
      ctx.beginPath();
      ctx.ellipse(-r * 0.3, -r * 0.45, r * 0.3, r * 0.17, -0.5, 0, TAU);
      ctx.fill();
      if (e.type === "jelly") {
        ctx.fillStyle = "rgba(255,255,255,.35)";
        ctx.beginPath();
        ctx.arc(0, 3, r * 0.35, 0, TAU);
        ctx.fill();
      }
      // eyes
      const ea = Math.atan2(p.y - e.y, p.x - e.x);
      const ex = Math.cos(ea) * r * 0.1;
      const ey = Math.sin(ea) * r * 0.1;
      const er = e.type === "bat" ? r * 0.3 : r * 0.26;
      for (const s of [-1, 1]) {
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(s * r * 0.36, -r * 0.2, er, 0, TAU);
        ctx.fill();
        ctx.fillStyle = frozen ? "#4a7aa8" : e.type === "brute" ? "#ff2a2a" : "#1a1226";
        ctx.beginPath();
        ctx.arc(s * r * 0.36 + ex * 2, -r * 0.2 + ey * 2, er * 0.5, 0, TAU);
        ctx.fill();
      }
      if (e.type === "brute") {
        ctx.strokeStyle = "#2a0d0d";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(-r * 0.7, -r * 0.55); ctx.lineTo(-r * 0.1, -r * 0.3);
        ctx.moveTo(r * 0.7, -r * 0.55); ctx.lineTo(r * 0.1, -r * 0.3);
        ctx.stroke();
      }
      if (e.type === "spitter") {
        const charge = e.shootT < 0.45 ? 1 - e.shootT / 0.45 : 0;
        ctx.fillStyle = "#2a1020";
        ctx.beginPath();
        ctx.ellipse(0, r * 0.35, r * 0.28, r * 0.2 + charge * 2, 0, 0, TAU);
        ctx.fill();
        if (charge > 0) {
          ctx.fillStyle = `rgba(255,93,158,${charge})`;
          ctx.beginPath();
          ctx.arc(0, r * 0.35, 3 + charge * 3, 0, TAU);
          ctx.fill();
        }
      }
      if (frozen) {
        ctx.strokeStyle = "rgba(255,255,255,.9)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 1.05, r * 0.95, 0, 0, TAU);
        ctx.stroke();
        ctx.fillStyle = "rgba(210,240,255,.7)";
        ctx.beginPath();
        ctx.moveTo(-r * 0.6, -r * 0.8); ctx.lineTo(-r * 0.35, -r * 1.35); ctx.lineTo(-r * 0.1, -r * 0.85);
        ctx.moveTo(r * 0.2, -r * 0.9); ctx.lineTo(r * 0.5, -r * 1.4); ctx.lineTo(r * 0.7, -r * 0.7);
        ctx.fill();
      } else if (e.chill > 0) {
        ctx.strokeStyle = `rgba(159,220,255,${0.3 + e.chill * 0.25})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 1.05, r * 0.95, 0, 0, TAU);
        ctx.stroke();
      }
      ctx.restore();
      // hp bar for big / damaged
      if (e.spawnT <= 0 && e.hp < e.maxHp && e.r >= 15) {
        const bw = e.r * 2;
        ctx.fillStyle = "rgba(0,0,0,.6)";
        ctx.fillRect(e.x - bw / 2, e.y - e.r - 12, bw, 4);
        ctx.fillStyle = e.color;
        ctx.fillRect(e.x - bw / 2, e.y - e.r - 12, bw * clamp(e.hp / e.maxHp, 0, 1), 4);
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawPlayer() {
    const ctx = this.ctx;
    const p = this.player;
    const blink = p.hurtT > 0 && Math.floor(this.time * 30) % 2 === 0;
    ctx.save();
    ctx.translate(p.x, p.y);
    // light
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.5;
    ctx.drawImage(glowSprite("#8a6cff"), -90, -90, 180, 180);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "rgba(0,0,0,.4)";
    ctx.beginPath();
    ctx.ellipse(0, 9, 11, 5, 0, 0, TAU);
    ctx.fill();
    if (blink) ctx.globalAlpha = 0.4;
    const moving = Math.hypot(p.vx, p.vy) > 60;
    const bob = moving ? Math.sin(this.time * 18) * 1.2 : Math.sin(this.time * 3) * 0.6;
    ctx.translate(0, bob);
    const flip = Math.cos(p.aim) < 0 ? -1 : 1;
    // robe
    ctx.fillStyle = "#3f2594";
    ctx.beginPath();
    ctx.ellipse(0, 3, 10, 9, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = p.inv > 0 && p.dashT > 0 ? "#ffffff" : "#6a43c9";
    ctx.beginPath();
    ctx.ellipse(0, 0, 9.5, 9, 0, 0, TAU);
    ctx.fill();
    // belt
    ctx.fillStyle = "#f2c14e";
    ctx.fillRect(-9, 2, 18, 2);
    // head + beard
    ctx.fillStyle = "#e8c9a4";
    ctx.beginPath();
    ctx.arc(flip * 2, -6, 5, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#e9e4f5";
    ctx.beginPath();
    ctx.ellipse(flip * 2, -2.5, 4, 3, 0, 0, Math.PI);
    ctx.fill();
    // eyes
    ctx.fillStyle = "#1a1226";
    ctx.fillRect(flip * 2 + flip * 1 - 1, -8, 1.6, 1.6);
    ctx.fillRect(flip * 2 - flip * 2 - 1, -8, 1.6, 1.6);
    // hat
    ctx.fillStyle = "#2d1b69";
    ctx.beginPath();
    ctx.ellipse(flip * 2, -10, 8.5, 3, 0, 0, TAU);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(flip * 2 - 5, -10);
    ctx.lineTo(flip * 2 - flip * 6, -23 + Math.sin(this.time * 4) * 1);
    ctx.lineTo(flip * 2 + 5, -10);
    ctx.fill();
    ctx.fillStyle = "#f2c14e";
    ctx.fillRect(flip * 2 - 5, -12, 10, 2);
    // wand
    ctx.rotate(p.aim);
    const off = -p.kick * 4;
    ctx.strokeStyle = "#a07a45";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(4 + off, 4);
    ctx.lineTo(22 + off, 4);
    ctx.stroke();
    ctx.fillStyle = "#e8c9a4";
    ctx.beginPath();
    ctx.arc(7 + off, 4, 2.6, 0, TAU);
    ctx.fill();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.8 + p.kick * 0.2;
    const gs = 18 + p.kick * 14;
    ctx.drawImage(glowSprite(this.nextColor), 23 + off - gs / 2, 4 - gs / 2, gs, gs);
    ctx.restore();
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
  }

  private drawEBullets() {
    const ctx = this.ctx;
    for (const b of this.ebul) {
      ctx.globalCompositeOperation = "lighter";
      ctx.drawImage(glowSprite("#ff5d9e"), b.x - 14, b.y - 14, 28, 28);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "#ff5d9e";
      ctx.beginPath();
      ctx.arc(b.x, b.y, 4.5, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.arc(b.x, b.y, 2, 0, TAU);
      ctx.fill();
    }
  }

  private drawProjs() {
    const ctx = this.ctx;
    // cores
    for (const q of this.projs) {
      const pd = q.pd;
      const r = pd.radius;
      const a = Math.atan2(q.vy, q.vx);
      if (pd.shape === "hole") {
        ctx.fillStyle = "#050208";
        ctx.beginPath();
        ctx.arc(q.x, q.y, r + 3 + Math.sin(this.time * 12) * 1.5, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = "#b88cff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(q.x, q.y, r + 4, q.age * 6, q.age * 6 + 4.2);
        ctx.stroke();
        ctx.strokeStyle = "#6a3cff";
        ctx.beginPath();
        ctx.arc(q.x, q.y, r + 8, -q.age * 4, -q.age * 4 + 3.6);
        ctx.stroke();
      } else if (pd.shape === "bomb") {
        ctx.fillStyle = "#2a2e40";
        ctx.beginPath();
        ctx.arc(q.x, q.y, r, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "#5a6283";
        ctx.beginPath();
        ctx.arc(q.x - 2.5, q.y - 2.5, r * 0.4, 0, TAU);
        ctx.fill();
        const blink = Math.floor(q.age * (6 + (1.1 - q.life) * 14)) % 2 === 0;
        ctx.fillStyle = blink ? "#ff4a3a" : "#ffd24d";
        ctx.beginPath();
        ctx.arc(q.x + 3, q.y - r - 1, 2.6, 0, TAU);
        ctx.fill();
      } else if (pd.shape === "bolt") {
        ctx.save();
        ctx.translate(q.x, q.y);
        ctx.rotate(a);
        const len = r * (pd.sound === "zap" ? 6 : 4.2);
        ctx.fillStyle = pd.color;
        ctx.beginPath();
        ctx.ellipse(-len * 0.3, 0, len * 0.7, r * 0.75, 0, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.ellipse(-len * 0.1, 0, len * 0.4, r * 0.38, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
      } else if (pd.shape === "shard") {
        ctx.save();
        ctx.translate(q.x, q.y);
        ctx.rotate(a);
        ctx.fillStyle = "#cfeeff";
        ctx.beginPath();
        ctx.moveTo(r * 2.2, 0); ctx.lineTo(0, -r * 0.9); ctx.lineTo(-r * 1.6, 0); ctx.lineTo(0, r * 0.9);
        ctx.fill();
        ctx.fillStyle = pd.color;
        ctx.beginPath();
        ctx.moveTo(r * 2.2, 0); ctx.lineTo(0, 0); ctx.lineTo(0, r * 0.9);
        ctx.fill();
        ctx.restore();
      } else {
        const rr = r * (pd.fx === "fire" ? 1 + Math.sin(this.time * 40) * 0.1 : 1) * (q.m.damage >= 6 ? 1.25 : 1);
        ctx.fillStyle = pd.color;
        ctx.beginPath();
        ctx.arc(q.x, q.y, rr, 0, TAU);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(q.x, q.y, rr * 0.5, 0, TAU);
        ctx.fill();
      }
      if (q.payload && !q.pfired) {
        ctx.strokeStyle = "#3de0a0";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(q.x, q.y, r + 4 + Math.sin(this.time * 14) * 1.2, 0, TAU);
        ctx.stroke();
      }
    }
    // glows
    ctx.globalCompositeOperation = "lighter";
    for (const q of this.projs) {
      const pd = q.pd;
      const s = pd.radius * (pd.shape === "hole" ? 14 : 6.5) * (q.m.damage >= 6 ? 1.2 : 1);
      ctx.drawImage(glowSprite(pd.color), q.x - s, q.y - s, s * 2, s * 2);
    }
    ctx.globalCompositeOperation = "source-over";
  }

  private drawParticles() {
    const ctx = this.ctx;
    const ps = this.parts;
    for (let pass = 0; pass < 2; pass++) {
      const add = pass === 1;
      ctx.globalCompositeOperation = add ? "lighter" : "source-over";
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        if (p.add !== add) continue;
        const k = p.life / p.max;
        const s = p.shrink ? p.size * (0.3 + 0.7 * k) : p.size * (1.6 - k * 0.6);
        ctx.globalAlpha = Math.min(1, k * 1.6);
        if (add && p.size >= 12) {
          const gs = s * 1.6;
          ctx.drawImage(glowSprite(p.color), p.x - gs, p.y - gs, gs * 2, gs * 2);
          continue;
        }
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private drawArcs() {
    const ctx = this.ctx;
    ctx.globalCompositeOperation = "lighter";
    ctx.lineJoin = "round";
    for (const a of this.arcs) {
      ctx.strokeStyle = a.color;
      ctx.globalAlpha = Math.min(1, a.life * 8);
      ctx.lineWidth = a.color === "#ffffff" ? 2 : 5;
      for (let i = 0; i + 3 < a.pts.length; i += 4) {
        const x0 = a.pts[i], y0 = a.pts[i + 1], x1 = a.pts[i + 2], y1 = a.pts[i + 3];
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        const n = 5;
        for (let k = 1; k < n; k++) {
          const t = k / n;
          ctx.lineTo(x0 + (x1 - x0) * t + rand(-9, 9), y0 + (y1 - y0) * t + rand(-9, 9));
        }
        ctx.lineTo(x1, y1);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private drawRings() {
    const ctx = this.ctx;
    for (const r of this.rings) {
      const k = 1 - r.life / r.max;
      const e = 1 - (1 - k) * (1 - k);
      const rad = r.r0 + (r.r1 - r.r0) * e;
      if (r.flash) {
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = (1 - k) * 0.9;
        ctx.drawImage(glowSprite(r.color), r.x - rad, r.y - rad, rad * 2, rad * 2);
        ctx.globalCompositeOperation = "source-over";
      } else {
        ctx.globalAlpha = 1 - k;
        ctx.strokeStyle = r.color;
        ctx.lineWidth = r.width * (1 - k * 0.7);
        ctx.beginPath();
        ctx.arc(r.x, r.y, rad, 0, TAU);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawTexts() {
    const ctx = this.ctx;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    for (const t of this.texts) {
      const k = t.life / t.max;
      const pop = 1 + Math.max(0, k - 0.8) * 3;
      ctx.globalAlpha = Math.min(1, k * 2.5);
      ctx.font = `${Math.round(t.size * pop)}px VT323, monospace`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(10,6,20,.9)";
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
  }

  // ------------------------------------------------------------ HUD
  private bar(x: number, y: number, w: number, h: number, frac: number, lag: number, color: string, border = "rgba(255,255,255,.25)") {
    const ctx = this.ctx;
    ctx.fillStyle = "rgba(8,6,18,.75)";
    ctx.fillRect(x, y, w, h);
    if (lag > frac) {
      ctx.fillStyle = "rgba(255,255,255,.7)";
      ctx.fillRect(x, y, w * clamp(lag, 0, 1), h);
    }
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w * clamp(frac, 0, 1), h);
    ctx.fillStyle = "rgba(255,255,255,.2)";
    ctx.fillRect(x, y, w * clamp(frac, 0, 1), Math.max(1, h * 0.3));
    ctx.strokeStyle = border;
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
  }

  private drawHud() {
    const ctx = this.ctx;
    const w = this.w;
    const h = this.h;
    const p = this.player;
    const narrow = w < 640 || this.input.touchMode;
    const pad = 12;
    const bw = narrow ? 118 : 170;
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = "left";
    ctx.lineJoin = "round";

    // HP
    this.bar(pad, pad, bw, 16, p.hp / p.maxHp, this.hpLag / p.maxHp, p.hp < 30 && Math.floor(this.time * 6) % 2 ? "#ff9ab0" : "#ff4d6d");
    ctx.font = "16px VT323, monospace";
    ctx.fillStyle = "#fff";
    ctx.fillText(`HP ${Math.ceil(p.hp)}`, pad + 6, pad + 13);
    // mana
    const manaBlink = this.noMana > 0 && Math.floor(this.time * 20) % 2 === 0;
    this.bar(pad, pad + 22, bw, 12, p.mana / p.maxMana, 0, "#4aa8ff", manaBlink ? "#ff4d6d" : "rgba(255,255,255,.25)");
    ctx.font = "14px VT323, monospace";
    ctx.fillStyle = "#e8f3ff";
    ctx.fillText(`MANA ${Math.floor(p.mana)}`, pad + 6, pad + 32);
    // dash
    const dr = 1 - p.dashCd / 0.95;
    ctx.fillStyle = "rgba(8,6,18,.75)";
    ctx.fillRect(pad, pad + 40, bw, 5);
    ctx.fillStyle = dr >= 1 ? "#ffd166" : "#8a7a50";
    ctx.fillRect(pad, pad + 40, bw * dr, 5);

    // score
    ctx.textAlign = "center";
    const sc = 1 + this.scorePunch * 0.25;
    ctx.save();
    ctx.translate(w / 2, pad + 26);
    ctx.scale(sc, sc);
    ctx.font = `${narrow ? 34 : 40}px VT323, monospace`;
    ctx.lineWidth = 5;
    ctx.strokeStyle = "rgba(10,6,20,.9)";
    const st = String(Math.round(this.shownScore)).padStart(6, "0");
    ctx.strokeText(st, 0, 0);
    ctx.fillStyle = this.scorePunch > 0.2 ? "#fff3b0" : "#ffd166";
    ctx.fillText(st, 0, 0);
    ctx.restore();

    // wave (right)
    ctx.textAlign = "right";
    if (narrow) {
      ctx.font = "20px VT323, monospace";
      ctx.fillStyle = "#cbb8ff";
      ctx.fillText(`WAVE ${this.wave} · ${this.queue.length + this.enemies.length} foes`, w - 12, pad + 70);
    } else {
      ctx.font = "22px VT323, monospace";
      ctx.fillStyle = "#cbb8ff";
      ctx.fillText(`WAVE ${this.wave}`, w - 112, pad + 22);
      ctx.font = "16px VT323, monospace";
      ctx.fillStyle = "#8a7fb0";
      ctx.fillText(`FOES ${this.queue.length + this.enemies.length}`, w - 112, pad + 40);
    }

    // combo
    ctx.textAlign = "center";
    if (this.combo >= 2) {
      const m = this.mult();
      ctx.font = `${narrow ? 22 : 26}px VT323, monospace`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(10,6,20,.9)";
      const t = `COMBO ${this.combo}  x${m.toFixed(1)}`;
      const cy = pad + 62;
      ctx.strokeText(t, w / 2, cy);
      ctx.fillStyle = this.combo >= 20 ? "#ff7ad9" : this.combo >= 10 ? "#ff9a4d" : "#ffe08a";
      ctx.fillText(t, w / 2, cy);
      ctx.fillStyle = "rgba(255,255,255,.2)";
      ctx.fillRect(w / 2 - 50, cy + 6, 100, 4);
      ctx.fillStyle = "#ffd166";
      ctx.fillRect(w / 2 - 50, cy + 6, 100 * clamp(this.comboT / 3.2, 0, 1), 4);
    }

    this.drawWandBar(narrow);

    // banner
    if (this.banner.t > 0) {
      const b = this.banner;
      const k = 1 - b.t / b.max;
      const a = Math.min(1, k * 6, b.t * 2.5);
      const sc2 = 1 + (1 - Math.min(1, k * 5)) * 0.6;
      ctx.save();
      ctx.globalAlpha = Math.max(0, a);
      ctx.translate(w / 2, h * 0.3);
      ctx.scale(sc2, sc2);
      ctx.font = `${narrow ? 18 : 26}px "Press Start 2P", monospace`;
      ctx.lineWidth = 6;
      ctx.strokeStyle = "rgba(10,6,20,.95)";
      ctx.strokeText(b.text, 0, 0);
      ctx.fillStyle = b.color;
      ctx.fillText(b.text, 0, 0);
      ctx.font = "24px VT323, monospace";
      ctx.lineWidth = 4;
      ctx.strokeText(b.sub, 0, 34);
      ctx.fillStyle = "#e8e0ff";
      ctx.fillText(b.sub, 0, 34);
      ctx.restore();
    }

    // hint
    if (this.hint > 0 && this.phase === "playing") {
      ctx.globalAlpha = Math.min(1, this.hint);
      ctx.font = `${narrow ? 18 : 22}px VT323, monospace`;
      ctx.fillStyle = "#e8e0ff";
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(10,6,20,.9)";
      const lines = this.input.touchMode
        ? ["LEFT STICK move  ·  RIGHT STICK aim + fire", "DASH button dodges  ·  more spells after each wave"]
        : ["WASD move  ·  MOUSE aim + hold click to fire  ·  SPACE dash", "Arrow keys also aim + fire  ·  Esc pauses"];
      const y0 = narrow ? h - 150 : h - 112;
      lines.forEach((l, i) => {
        ctx.strokeText(l, w / 2, y0 + i * 22);
        ctx.fillText(l, w / 2, y0 + i * 22);
      });
      ctx.globalAlpha = 1;
    }
  }

  private drawWandBar(narrow: boolean) {
    const ctx = this.ctx;
    const w = this.w;
    const h = this.h;
    const ss = narrow ? 30 : 38;
    const gap = 5;
    const n = this.wand.length;
    const total = n * ss + (n - 1) * gap;
    const x0 = Math.round((w - total) / 2);
    const y0 = narrow ? 100 : h - ss - 22;
    const p = this.player;

    // background plate
    ctx.fillStyle = "rgba(8,6,18,.6)";
    ctx.fillRect(x0 - 8, y0 - 6, total + 16, ss + 12);
    ctx.strokeStyle = "rgba(160,130,255,.3)";
    ctx.lineWidth = 2;
    ctx.strokeRect(x0 - 8, y0 - 6, total + 16, ss + 12);

    let ci = 0;
    const lc = this.lastCast;
    const sp = compact(this.wand);
    const nextIdx = this.ptr >= sp.length ? 0 : this.ptr;
    for (let i = 0; i < n; i++) {
      const id = this.wand[i];
      const x = x0 + i * (ss + gap);
      const def = id ? SPELLS[id] : null;
      let active = false;
      let isNext = false;
      if (def) {
        active = lc.t > 0 && ci >= lc.start && ci < lc.end;
        isNext = ci === nextIdx;
        ci++;
      }
      const col = def ? KIND_COLOR[def.kind] : "rgba(160,130,255,.3)";
      ctx.fillStyle = active ? "rgba(255,255,255,.28)" : "rgba(20,16,40,.9)";
      ctx.fillRect(x, y0, ss, ss);
      if (def) {
        const lift = active ? -3 * (lc.t / 0.35) : 0;
        ctx.drawImage(getIcon(def.id), x + 2, y0 + 2 + lift, ss - 4, ss - 4);
      }
      ctx.strokeStyle = active ? "#fff" : col;
      ctx.lineWidth = active ? 3 : 2;
      if (!def) ctx.setLineDash([3, 3]);
      ctx.strokeRect(x, y0, ss, ss);
      ctx.setLineDash([]);
      if (isNext && def) {
        ctx.fillStyle = "#fff";
        const cx = x + ss / 2;
        const ty = narrow ? y0 + ss + 4 : y0 - 5;
        ctx.beginPath();
        if (narrow) { ctx.moveTo(cx - 4, ty + 5); ctx.lineTo(cx + 4, ty + 5); ctx.lineTo(cx, ty); }
        else { ctx.moveTo(cx - 4, ty - 5); ctx.lineTo(cx + 4, ty - 5); ctx.lineTo(cx, ty); }
        ctx.fill();
      }
    }
    // cooldown / recharge bar
    const cd = clamp(1 - p.castT / Math.max(0.05, p.castCd), 0, 1);
    const by = narrow ? y0 + ss + 9 : y0 + ss + 1;
    ctx.fillStyle = "rgba(255,255,255,.12)";
    ctx.fillRect(x0, by, total, 3);
    ctx.fillStyle = p.castCd > BASE_DELAY + 0.2 ? "#ffa033" : "#7ff";
    ctx.fillRect(x0, by, total * cd, 3);
  }

  private drawTouch() {
    const ctx = this.ctx;
    const inp = this.input;
    ctx.lineWidth = 3;
    for (const s of [inp.move, inp.aim]) {
      if (!s.active) continue;
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = s === inp.aim ? "#ffa033" : "#7ff";
      ctx.fillStyle = "rgba(255,255,255,.06)";
      ctx.beginPath();
      ctx.arc(s.ox, s.oy, STICK_R, 0, TAU);
      ctx.fill();
      ctx.stroke();
      ctx.globalAlpha = 0.85;
      ctx.fillStyle = s === inp.aim ? "#ffb15c" : "#9ff";
      ctx.beginPath();
      ctx.arc(s.ox + s.kx, s.oy + s.ky, 22, 0, TAU);
      ctx.fill();
    }
    // hints when idle
    if (!inp.move.active || !inp.aim.active) {
      ctx.globalAlpha = 0.18;
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      if (!inp.move.active) { ctx.beginPath(); ctx.arc(this.w * 0.2, this.h * 0.78, STICK_R, 0, TAU); ctx.stroke(); }
      if (!inp.aim.active) { ctx.beginPath(); ctx.arc(this.w * 0.62, this.h * 0.78, STICK_R, 0, TAU); ctx.stroke(); }
    }
    // dash button
    const d = inp.dashBtn();
    const ready = this.player.dashCd <= 0;
    ctx.globalAlpha = inp.dashHeld ? 0.9 : ready ? 0.6 : 0.3;
    ctx.fillStyle = ready ? "rgba(255,209,102,.25)" : "rgba(255,255,255,.08)";
    ctx.strokeStyle = ready ? "#ffd166" : "#8a7a50";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(d.x, d.y, d.r, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = ready ? "#ffd166" : "#8a7a50";
    ctx.font = "16px VT323, monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("DASH", d.x, d.y);
    ctx.globalAlpha = 1;
    ctx.textBaseline = "alphabetic";
  }

  // exposed for UI (optional)
  get currentWave() {
    return this.wave;
  }
}


