import { useCallback, useEffect, useRef, useState } from "react";
import { Game } from "./game/engine";
import type { AltarData, OverData, Phase } from "./game/engine";
import { sfx } from "./game/audio";
import { addScore, loadName, loadScores, saveName } from "./game/scores";
import type { ScoreEntry } from "./game/scores";
import { Altar } from "./ui/Altar";
import { ScoreTable, SpellIcon } from "./ui/parts";

function MenuScreen({ name, setName, scores, onPlay }: { name: string; setName: (n: string) => void; scores: ScoreEntry[]; onPlay: () => void }) {
  const [help, setHelp] = useState(false);
  return (
    <div className="absolute inset-0 z-20 overflow-y-auto scroll-thin flex bg-[radial-gradient(ellipse_at_center,rgba(10,5,25,0.55),rgba(5,2,12,0.92))]">
      <div className="m-auto w-full max-w-3xl px-4 py-6 flex flex-col items-center">
        <div className="flex gap-3 mb-4 pop-in">
          {["fireball", "double", "lightning", "trigger", "frost"].map((id, i) => (
            <div key={id} className="float" style={{ animationDelay: i * 0.25 + "s" }}>
              <SpellIcon id={id} size={36} />
            </div>
          ))}
        </div>
        <h1 className="title-glow font-pixel text-[30px] sm:text-[52px] leading-tight text-center pop-in">HEX WEAVER</h1>
        <p className="font-vt text-[22px] sm:text-[26px] text-[#cbb8ff] mt-2 text-center">Chain spells. Combine elements. Break the cave.</p>

        <div className="flex flex-col sm:flex-row gap-5 mt-6 w-full items-stretch">
          <div className="panel p-4 flex-1 flex flex-col items-center gap-4 justify-center">
            <label className="font-pixel text-[9px] text-[#8a7fb0] w-full">
              WIZARD NAME
              <input
                value={name}
                maxLength={8}
                onChange={(e) => setName(e.target.value.toUpperCase().replace(/[^A-Z0-9 _-]/g, ""))}
                className="mt-2 w-full bg-[#0a0616] border-2 border-[#4a3a8a] px-3 py-2 font-vt text-[26px] text-[#ffd166] outline-none focus:border-[#ffd166] tracking-widest text-center"
                spellCheck={false}
                autoComplete="off"
              />
            </label>
            <button className="btn btn-go w-full" onClick={onPlay}>
              ▶ ENTER THE CAVE
            </button>
            <button className="btn btn-ghost w-full !text-[10px]" onClick={() => setHelp((h) => !h)}>
              {help ? "HIDE" : "HOW TO PLAY"}
            </button>
          </div>
          <div className="panel p-4 flex-1">
            <div className="font-pixel text-[10px] text-[#ffd166] mb-3 text-center">HALL OF HEXES</div>
            <ScoreTable scores={scores} compact />
          </div>
        </div>

        {help && (
          <div className="panel p-4 mt-5 w-full font-vt text-[20px] leading-6 text-[#cfc6ee] pop-in">
            <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3">
              <div>
                <div className="font-pixel text-[9px] text-[#ffd166] mb-1">CONTROLS</div>
                <div><b className="text-white">WASD</b> move · <b className="text-white">MOUSE</b> aim, hold click to fire</div>
                <div><b className="text-white">SPACE / RIGHT-CLICK</b> dash (dodge through foes)</div>
                <div><b className="text-white">ARROW KEYS</b> aim + fire · <b className="text-white">ESC</b> pause · <b className="text-white">R</b> restart · <b className="text-white">M</b> mute</div>
                <div><b className="text-white">TOUCH</b>: left stick moves, right stick aims + fires, DASH button dodges</div>
              </div>
              <div>
                <div className="font-pixel text-[9px] text-[#ffd166] mb-1">YOUR WAND</div>
                <div>Spells cast <b className="text-white">in order</b>, left to right, looping. After each wave claim a new spell and rearrange.</div>
                <div><span className="text-[#c58bff]">Multicast</span> fires the next spells together. <span className="text-[#4aa8ff]">Modifiers</span> buff the next projectile. <span className="text-[#3de0a0]">Trigger</span> casts the spell after it on impact.</div>
              </div>
              <div className="sm:col-span-2">
                <div className="font-pixel text-[9px] text-[#ffd166] mb-1">ELEMENT REACTIONS</div>
                <div><span className="text-[#9fdcff]">Frost ×3</span> freezes · frozen + <span className="text-[#ffb066]">fire</span> = <b className="text-white">STEAM</b> · frozen + blast / <span className="text-[#ff6b6b]">heavy</span> = <b className="text-white">SHATTER</b> · burning + <span className="text-[#ffee55]">lightning</span> = <b className="text-white">OVERLOAD</b></div>
                <div className="text-[#a79fd0]">Chain kills to build a combo multiplier. Getting hit breaks it.</div>
              </div>
            </div>
          </div>
        )}
        <div className="font-vt text-[18px] text-[#6c6290] mt-4 blink">press ENTER to start</div>
      </div>
    </div>
  );
}

function PauseScreen({ wand, onResume, onRestart, onMenu }: { wand: (string | null)[]; onResume: () => void; onRestart: () => void; onMenu: () => void }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-[#05030c]/75 backdrop-blur-[2px] p-3">
      <div className="panel pop-in p-6 w-full max-w-sm flex flex-col gap-3 items-center">
        <div className="font-pixel text-[20px] text-[#cbb8ff] mb-1">PAUSED</div>
        <div className="flex flex-wrap gap-1 justify-center mb-2">
          {wand.map((id, i) => (
            <div key={i} className="w-9 h-9 border-2 border-[#3a2d70] bg-[#0a0616] flex items-center justify-center">
              {id && <SpellIcon id={id} size={28} />}
            </div>
          ))}
        </div>
        <button className="btn btn-go w-full" onClick={onResume}>RESUME</button>
        <button className="btn w-full" onClick={onRestart}>RESTART (R)</button>
        <button className="btn btn-ghost w-full" onClick={onMenu}>MAIN MENU</button>
        <div className="font-vt text-[17px] text-[#6c6290]">ESC to resume</div>
      </div>
    </div>
  );
}

function OverScreen({ res, scores, rank, name, onAgain, onMenu }: { res: OverData; scores: ScoreEntry[]; rank: number; name: string; onAgain: () => void; onMenu: () => void }) {
  const mins = Math.floor(res.time / 60);
  const secs = Math.floor(res.time % 60).toString().padStart(2, "0");
  return (
    <div className="absolute inset-0 z-20 overflow-y-auto scroll-thin flex bg-[#0a0210]/80 backdrop-blur-[2px]">
      <div className="panel pop-in m-auto p-5 sm:p-6 w-full max-w-md my-4 mx-2 sm:mx-auto flex flex-col items-center">
        <div className="font-pixel text-[20px] sm:text-[24px] text-[#ff4d6d] mb-1" style={{ textShadow: "0 0 18px rgba(255,60,100,.7)" }}>HEX BROKEN</div>
        <div className="font-vt text-[20px] text-[#a79fd0] mb-3">{name} fell on wave {res.wave}</div>
        <div className="font-vt text-[56px] leading-none text-[#ffd166]" style={{ textShadow: "0 0 20px rgba(255,190,80,.5)" }}>{res.score.toLocaleString()}</div>
        {rank === 0 && <div className="font-pixel text-[10px] text-[#7dff9a] mt-2 blink">★ NEW HIGH SCORE ★</div>}
        {rank > 0 && <div className="font-pixel text-[9px] text-[#7dff9a] mt-2">RANK #{rank + 1} IN THE HALL</div>}
        <div className="grid grid-cols-3 gap-2 w-full my-4 text-center font-vt text-[18px]">
          <div className="bg-[#0a0616] border-2 border-[#2c2258] p-1.5"><div className="text-[#8a7fb0] text-[15px]">KILLS</div><div className="text-white text-[24px] leading-6">{res.kills}</div></div>
          <div className="bg-[#0a0616] border-2 border-[#2c2258] p-1.5"><div className="text-[#8a7fb0] text-[15px]">BEST COMBO</div><div className="text-white text-[24px] leading-6">{res.bestCombo}</div></div>
          <div className="bg-[#0a0616] border-2 border-[#2c2258] p-1.5"><div className="text-[#8a7fb0] text-[15px]">TIME</div><div className="text-white text-[24px] leading-6">{mins}:{secs}</div></div>
        </div>
        <div className="w-full mb-4">
          <ScoreTable scores={scores} highlight={rank} />
        </div>
        <button className="btn btn-go w-full" onClick={onAgain}>↻ PLAY AGAIN (R / ENTER)</button>
        <button className="btn btn-ghost w-full mt-3 !text-[10px]" onClick={onMenu}>MAIN MENU</button>
      </div>
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const nameRef = useRef(loadName());
  const [name, setNameState] = useState(nameRef.current);
  const [phase, setPhase] = useState<Phase>("menu");
  const [altar, setAltar] = useState<AltarData | null>(null);
  const [over, setOver] = useState<{ res: OverData; scores: ScoreEntry[]; rank: number; name: string } | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [muted, setMuted] = useState(sfx.muted);
  const [wandSnap, setWandSnap] = useState<(string | null)[]>([]);

  const setName = useCallback((n: string) => {
    nameRef.current = n;
    setNameState(n);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const game = new Game(canvas, {
      onPhase: (p) => {
        setPhase(p);
        if (p === "paused") setWandSnap(game.wand.slice());
        if (p === "menu") setScores(loadScores());
      },
      onAltar: (a) => setAltar(a),
      onOver: (res) => {
        const nm = (nameRef.current.trim() || "WIZ").slice(0, 8);
        saveName(nm);
        const r = res.score > 0
          ? addScore({ name: nm, score: res.score, wave: res.wave, kills: res.kills, date: Date.now() })
          : { scores: loadScores(), rank: -1 };
        setScores(r.scores);
        setOver({ res, scores: r.scores, rank: r.rank, name: nm });
      },
    });
    gameRef.current = game;
    const onResize = () => game.resize();
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    document.fonts?.load("20px VT323");
    document.fonts?.load("20px 'Press Start 2P'");
    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  const play = () => {
    sfx.unlock();
    saveName(nameRef.current.trim() || "WIZ");
    gameRef.current?.startGame();
  };

  return (
    <div className="fixed inset-0 bg-ink overflow-hidden select-none">
      <canvas ref={canvasRef} className="absolute inset-0 touch-none" />
      <div className="vignette pointer-events-none absolute inset-0 z-10" />
      <div className="scanlines pointer-events-none absolute inset-0 z-10 opacity-60" />

      {phase === "playing" && (
        <div className="absolute z-10 top-2 right-2 flex gap-2">
          <button
            aria-label="Mute"
            className="w-10 h-10 bg-[#120d22]/80 border-2 border-[#4a3a8a] text-[#cbb8ff] font-pixel text-[10px] active:scale-95"
            onClick={() => {
              sfx.setMuted(!sfx.muted);
              setMuted(sfx.muted);
            }}
          >
            {muted ? "🔇" : "🔊"}
          </button>
          <button
            aria-label="Pause"
            className="w-10 h-10 bg-[#120d22]/80 border-2 border-[#4a3a8a] text-[#cbb8ff] font-pixel text-[12px] active:scale-95"
            onClick={() => gameRef.current?.pause()}
          >
            ❚❚
          </button>
        </div>
      )}

      {phase === "menu" && <MenuScreen name={name} setName={setName} scores={scores} onPlay={play} />}
      {phase === "paused" && (
        <PauseScreen
          wand={wandSnap}
          onResume={() => gameRef.current?.resume()}
          onRestart={() => gameRef.current?.startGame()}
          onMenu={() => gameRef.current?.toMenu()}
        />
      )}
      {phase === "altar" && altar && <Altar key={altar.wave} data={altar} onDone={(w) => gameRef.current?.nextWave(w)} />}
      {phase === "over" && over && (
        <OverScreen res={over.res} scores={over.scores} rank={over.rank} name={over.name} onAgain={() => gameRef.current?.startGame()} onMenu={() => gameRef.current?.toMenu()} />
      )}
    </div>
  );
}
